<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// Redirect if already logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    if ($_SESSION['user_role'] === 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: user/dashboard.php');
    }
    exit();
}

$error = '';
$success = '';
$token = '';
$token_valid = false;

// Get token from URL
if (isset($_GET['token'])) {
    $token = sanitize_input($_GET['token']);

    // Verify token
    $verification = verify_reset_token($token);
    if ($verification['success']) {
        $token_valid = true;
    } else {
        $error = $verification['message'];
    }
}

// Process password reset
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $token_valid) {
    $new_password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($new_password) || empty($confirm_password)) {
        $error = 'Please fill in all fields';
    } elseif (strlen($new_password) < 6) {
        $error = 'Password must be at least 6 characters long';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Passwords do not match';
    } else {
        $result = reset_password($token, $new_password);

        if ($result['success']) {
            $success = $result['message'];
            $token_valid = false; // Prevent form from showing again
        } else {
            $error = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - HealthGuard</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="navbar-brand">🛡️ HealthGuard</a>
            <ul class="navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php">Sign Up</a></li>
            </ul>
        </div>
    </nav>

    <!-- Reset Password Form -->
    <div class="wrapper" style="display: flex; align-items: center; justify-content: center; min-height: calc(100vh - 80px);">
        <div class="container" style="max-width: 500px;">
            <div class="card">
                <div class="card-header text-center">
                    <h2 class="card-title">Reset Password</h2>
                    <p class="text-muted">Enter your new password</p>
                </div>

                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <?php if ($success): ?>
                        <div class="alert alert-success">
                            <?php echo htmlspecialchars($success); ?>
                            <p style="margin-top: 1rem;">
                                <a href="login.php" class="btn btn-primary btn-block">Go to Login</a>
                            </p>
                        </div>
                    <?php elseif ($token_valid): ?>
                        <form method="POST" action="">
                            <div class="form-group">
                                <label class="form-label">New Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Minimum 6 characters" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Confirm New Password</label>
                                <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter password" required>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block">Reset Password</button>
                        </form>
                    <?php elseif (!$token): ?>
                        <div class="alert alert-danger">
                            No reset token provided. Please use the link from your email.
                        </div>
                        <a href="forgot_password.php" class="btn btn-primary btn-block">Request New Reset Link</a>
                    <?php endif; ?>

                    <div style="margin-top: 1.5rem; text-align: center;">
                        <p class="text-muted">
                            Remember your password?
                            <a href="login.php" style="color: var(--primary-solid); font-weight: 600;">Sign In</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>