# 🛡️ HealthGuard - Disease Prevention & Monitoring System

A comprehensive web-based health monitoring system designed for hackathons, featuring vitals tracking, AI-powered disease risk assessment, and admin management capabilities.

## ✨ Features

### User Features

- ✅ **User Authentication** - Secure signup/login with password hashing
- ✅ **Password Recovery** - Email-based password reset with secure tokens
- ✅ **Vitals Tracking** - Monitor blood pressure, heart rate, sugar level, and temperature
- ✅ **Risk Assessment** - Automated disease risk calculation (Low, Medium, High)
- ✅ **Interactive Charts** - Visualize health trends with Chart.js
- ✅ **Health Notifications** - Receive alerts and daily health tips
- ✅ **Profile Management** - Update personal information
- ✅ **Profile Picture Upload** - Upload and manage profile pictures (JPG, PNG, GIF)
- ✅ **History Tracking** - View complete vitals history

### Admin Features

- ✅ **Admin Dashboard** - System overview with statistics
- ✅ **User Management** - View all users and their health data
- ✅ **Risk Monitoring** - Filter and view high-risk users
- ✅ **Notification System** - Send notifications to all or specific users
- ✅ **Health Tips Templates** - Pre-defined health tips for quick sending
- ✅ **Reports Generation** - Export comprehensive CSV reports

### Technical Features

- ✅ **Secure Authentication** - Password hashing with PHP's `password_hash()`
- ✅ **SQL Injection Prevention** - PDO prepared statements throughout
- ✅ **XSS Prevention** - Input sanitization on all user inputs
- ✅ **Role-Based Access Control** - Separate user and admin interfaces
- ✅ **Mobile-First Design** - Fully responsive on all devices
- ✅ **Premium UI/UX** - Glassmorphism, gradients, and smooth animations

## 🚀 Quick Start

### Prerequisites

- **XAMPP** (or any PHP development environment)
  - PHP 7.4 or higher
  - MySQL 5.7 or higher
  - Apache Web Server

### Installation Steps

#### 1. Clone/Download Project

The project is already in your `C:\xampp\htdocs\HealthGuard` directory.

#### 2. Start XAMPP

- Open XAMPP Control Panel
- Start **Apache** and **MySQL** services

#### 3. Create Database

1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Click "New" to create a new database
3. Database name: `healthguard`
4. Collation: `utf8mb4_unicode_ci`
5. Click "Create"

#### 4. Import Database Schema

1. Select the `healthguard` database
2. Click "Import" tab
3. Click "Choose File"
4. Navigate to: `C:\xampp\htdocs\HealthGuard\database\schema.sql`
5. Click "Go" to import
6. Repeat for `sample_data.sql` to add test data
7. **Important:** Import `password_reset_migration.sql` to enable password recovery feature

#### 5. Configure Database Connection (Optional)

If your MySQL credentials are different from defaults:

- Edit `config/database.php`
- Update `DB_USER` and `DB_PASS` if needed

#### 6. Access the Application

Open your browser and navigate to:

```
http://localhost/HealthGuard
```

## 🔐 Default Login Credentials

### Admin Account

- **Email:** admin@healthguard.com
- **Password:** password123

### Test User Accounts

- **Email:** john@example.com | **Password:** password123
- **Email:** jane@example.com | **Password:** password123
- **Email:** michael@example.com | **Password:** password123

## 📁 Project Structure

```
HealthGuard/
├── config/
│   └── database.php          # Database connection
├── includes/
│   ├── auth.php             # Authentication functions
│   ├── functions.php        # Utility functions
│   └── risk_algorithm.php   # Disease risk assessment
├── assets/
│   └── css/
│       └── style.css        # Premium design system
├── user/
│   ├── dashboard.php        # User dashboard
│   ├── profile.php          # Profile management
│   └── history.php          # Vitals history with charts
├── admin/
│   ├── dashboard.php        # Admin dashboard
│   ├── users.php            # User management
│   ├── notifications.php    # Notification system
│   └── reports.php          # Reports & CSV export
├── database/
│   ├── schema.sql           # Database schema
│   └── sample_data.sql      # Sample test data
├── index.php                # Landing page
├── login.php                # Login page
├── signup.php               # Registration page
└── logout.php               # Logout handler
```

## 🗄️ Database Schema

### Tables

#### `users`

- User accounts with role-based access (user/admin)
- Stores personal info: name, email, age, gender, location
- Passwords hashed with `PASSWORD_DEFAULT`

#### `vitals`

- Health measurements: BP, heart rate, sugar, temperature
- Linked to users via `user_id` foreign key
- Timestamped for historical tracking

#### `risk_assessments`

- Calculated risk levels (Low, Medium, High)
- Risk factors and personalized recommendations
- Linked to both users and vitals

#### `notifications`

- System and admin notifications
- Supports broadcast (NULL user_id) and individual messages
- Types: info, warning, alert, tip

## 🎯 Risk Assessment Algorithm

The system analyzes vitals using the following criteria:

### Blood Pressure

- **High Risk:** ≥140/90 mmHg (Hypertension)
- **Medium Risk:** 130-139/85-89 mmHg
- **Low Risk:** 90-129/60-84 mmHg

### Heart Rate

- **High Risk:** >100 bpm (Tachycardia)
- **Medium Risk:** 80-100 bpm
- **Low Risk:** 60-79 bpm

### Sugar Level

- **High Risk:** ≥126 mg/dL (Diabetes risk)
- **Medium Risk:** 100-125 mg/dL (Pre-diabetes)
- **Low Risk:** 70-99 mg/dL

### Temperature

- **High Risk:** ≥38°C (Fever) or <36°C (Hypothermia)
- **Medium Risk:** 37.5-37.9°C
- **Low Risk:** 36-37.4°C

Risk scores are cumulative, and the system provides specific recommendations based on detected issues.

## 🎨 Design Features

- **Glassmorphism Effects** - Modern frosted glass card designs
- **Vibrant Gradients** - Purple-pink color scheme
- **Smooth Animations** - Fade-in, hover effects, and transitions
- **Dark Theme** - Eye-friendly dark background
- **Responsive Grid** - Adapts to all screen sizes
- **Interactive Charts** - Real-time data visualization
- **Color-Coded Risks** - Green (Low), Yellow (Medium), Red (High)

## 🔒 Security Features

1. **Password Security**

   - Passwords hashed using `password_hash()` with `PASSWORD_DEFAULT`
   - Never stored in plain text

2. **SQL Injection Prevention**

   - All queries use PDO prepared statements
   - No direct SQL string concatenation

3. **XSS Prevention**

   - All user inputs sanitized with `htmlspecialchars()`
   - Output encoding on display

4. **Session Security**

   - Secure session management
   - Role-based access control
   - Automatic logout on session expiry

5. **Input Validation**
   - Server-side validation on all forms
   - Type checking and range validation

## 📊 Admin Features

### Dashboard

- Total users count
- High-risk users alert
- Risk distribution statistics
- Recent vitals submissions

### User Management

- View all users with risk levels
- Filter high-risk users
- View detailed user profiles
- Access user vitals history

### Notifications

- Send to all users (broadcast)
- Send to specific users
- Pre-defined health tips templates
- Notification history tracking

### Reports

- System statistics overview
- Risk distribution charts
- Average vitals calculation
- CSV export for data analysis

## 🧪 Testing

### Test the User Flow

1. Register a new account at `/signup.php`
2. Submit vitals on the dashboard
3. View risk assessment results
4. Check vitals history with charts
5. Update profile information
6. **Test password reset:** Logout, click "Forgot Password?", enter email, check for reset link in database, reset password

### Test the Admin Flow

1. Login as admin (admin@healthguard.com / password123)
2. View system statistics
3. Manage users and view their data
4. Send notifications to users
5. Export CSV reports

## 🎓 Hackathon Highlights

### Innovation

- AI-powered risk assessment algorithm
- Real-time health monitoring
- Preventive healthcare approach

### Technical Excellence

- Clean, maintainable code
- Secure coding practices
- Modern web technologies

### User Experience

- Intuitive interface
- Premium design aesthetics
- Mobile-first responsive

### Social Impact

- Disease prevention focus
- Health awareness promotion
- Accessible healthcare monitoring

## 📝 API Endpoints (Internal)

While this is a traditional PHP application, the following endpoints handle AJAX-style operations:

- `api/submit_vitals.php` - Process vitals submission
- `api/get_vitals.php` - Fetch vitals data for charts
- `api/send_notification.php` - Admin notification sending

## 🛠️ Troubleshooting

### Database Connection Error

- Verify MySQL is running in XAMPP
- Check database credentials in `config/database.php`
- Ensure database `healthguard` exists

### Login Not Working

- Clear browser cache and cookies
- Verify sample data was imported
- Check PHP session is enabled

### Charts Not Displaying

- Ensure internet connection (Chart.js loads from CDN)
- Check browser console for JavaScript errors

### Styles Not Loading

- Clear browser cache
- Verify `assets/css/style.css` exists
- Check file permissions

## 🚀 Future Enhancements

- Email notifications
- SMS alerts for high-risk users
- PDF report generation
- Multi-language support
- Mobile app integration
- Wearable device integration
- Telemedicine integration

## 👨‍💻 Development

### Technology Stack

- **Frontend:** HTML5, CSS3, JavaScript, Chart.js
- **Backend:** PHP 7.4+
- **Database:** MySQL 5.7+
- **Server:** Apache (XAMPP)

### Coding Standards

- PSR-12 PHP coding standards
- Semantic HTML5
- BEM CSS methodology
- ES6+ JavaScript

## 📄 License

This project is created for hackathon purposes and educational use.

## 🙏 Acknowledgments

- Chart.js for beautiful data visualization
- Google Fonts (Inter) for typography
- PHP community for security best practices

## 📞 Support

For issues or questions during the hackathon:

1. Check the troubleshooting section
2. Review the code comments
3. Test with provided sample accounts

---

**Built with ❤️ for Hackathon Excellence**

_HealthGuard - Your Health, Your Priority_
