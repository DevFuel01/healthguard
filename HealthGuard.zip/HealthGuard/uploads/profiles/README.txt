# Default avatar placeholder
# This directory contains user profile pictures
