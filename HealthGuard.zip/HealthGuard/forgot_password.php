<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';

// Redirect if already logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    if ($_SESSION['user_role'] === 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: user/dashboard.php');
    }
    exit();
}

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize_input($_POST['email']);

    if (empty($email)) {
        $message = 'Please enter your email address';
        $message_type = 'danger';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Please enter a valid email address';
        $message_type = 'danger';
    } else {
        $result = request_password_reset($email);
        $message = $result['message'];
        $message_type = 'success';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - HealthGuard</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="navbar-brand">🛡️ HealthGuard</a>
            <ul class="navbar-nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php">Sign Up</a></li>
            </ul>
        </div>
    </nav>

    <!-- Forgot Password Form -->
    <div class="wrapper" style="display: flex; align-items: center; justify-content: center; min-height: calc(100vh - 80px);">
        <div class="container" style="max-width: 500px;">
            <div class="card">
                <div class="card-header text-center">
                    <h2 class="card-title">Forgot Password?</h2>
                    <p class="text-muted">Enter your email to receive a password reset link</p>
                </div>

                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-<?php echo $message_type; ?>">
                            <?php echo htmlspecialchars($message); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="form-group">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="your@email.com" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">Send Reset Link</button>
                    </form>

                    <div style="margin-top: 1.5rem; text-align: center;">
                        <p class="text-muted">
                            Remember your password?
                            <a href="login.php" style="color: var(--primary-solid); font-weight: 600;">Sign In</a>
                        </p>
                    </div>

                    <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--border);">
                        <p class="text-muted" style="font-size: 0.875rem;">
                            <strong>Note:</strong> For security reasons, you will receive a confirmation message regardless of whether the email exists in our system. The reset link will expire in 1 hour.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>