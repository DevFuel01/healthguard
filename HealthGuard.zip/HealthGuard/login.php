<?php
require_once 'includes/auth.php';

// Redirect if already logged in
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    if ($_SESSION['user_role'] === 'admin') {
        header('Location: admin/dashboard.php');
    } else {
        header('Location: user/dashboard.php');
    }
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = 'Please fill in all fields';
    } else {
        $result = login_user($email, $password);

        if ($result['success']) {
            // Redirect based on role
            if ($result['role'] === 'admin') {
                header('Location: admin/dashboard.php');
            } else {
                header('Location: user/dashboard.php');
            }
            exit();
        } else {
            $error = $result['message'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - HealthGuard</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="index.php" class="navbar-brand">🛡️ HealthGuard</a>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="navbar-nav" id="navbarNav">
                <li><a href="index.php">Home</a></li>
                <li><a href="signup.php">Sign Up</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Hamburger menu toggle
        const hamburger = document.getElementById('hamburger');
        const navbarNav = document.getElementById('navbarNav');

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarNav.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            }
        });

        // Close menu when clicking on a link
        navbarNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            });
        });
    </script>

    <!-- Login Form -->
    <div class="wrapper" style="display: flex; align-items: center; justify-content: center; min-height: calc(100vh - 80px);">
        <div class="container" style="max-width: 450px;">
            <div class="card">
                <div class="card-header text-center">
                    <h2 class="card-title">Welcome Back</h2>
                    <p class="text-muted">Sign in to your HealthGuard account</p>
                </div>

                <div class="card-body">
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="form-group">
                            <label class="form-label">Email Address</label>
                            <input type="email" name="email" class="form-control" placeholder="your@email.com" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                            <div style="text-align: right; margin-top: 0.5rem;">
                                <a href="forgot_password.php" style="color: var(--primary-solid); font-size: 0.875rem; text-decoration: none;">Forgot Password?</a>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                    </form>

                    <div style="margin-top: 1.5rem; text-align: center;">
                        <p class="text-muted">Don't have an account? <a href="signup.php" style="color: var(--primary-solid); font-weight: 600;">Sign Up</a></p>
                    </div>

                    <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--border);">
                        <p class="text-muted" style="font-size: 0.875rem; text-align: center;">
                            <strong>Test Accounts:</strong><br>
                            Admin: admin@healthguard.com / password123<br>
                            User: john@example.com / password123
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>