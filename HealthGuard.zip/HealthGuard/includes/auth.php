<?php
// Authentication Functions
// HealthGuard - Disease Prevention & Monitoring System

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/database.php';

/**
 * Register a new user
 */
function register_user($name, $email, $password, $age = null, $gender = null, $location = null)
{
    global $pdo;

    // Check if email already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetch()) {
        return ['success' => false, 'message' => 'Email already registered'];
    }

    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert user
    $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role, age, gender, location) VALUES (?, ?, ?, 'user', ?, ?, ?)");

    try {
        $stmt->execute([$name, $email, $hashed_password, $age, $gender, $location]);
        return ['success' => true, 'message' => 'Registration successful'];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Registration failed: ' . $e->getMessage()];
    }
}

/**
 * Login user
 */
function login_user($email, $password)
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Set session variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['logged_in'] = true;

        return ['success' => true, 'role' => $user['role']];
    }

    return ['success' => false, 'message' => 'Invalid email or password'];
}

/**
 * Check if user is authenticated
 */
function check_auth()
{
    if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
        header('Location: /HealthGuard/login.php');
        exit();
    }
}

/**
 * Check if user has required role
 */
function check_role($required_role)
{
    check_auth();
    if ($_SESSION['user_role'] !== $required_role) {
        header('Location: /HealthGuard/index.php');
        exit();
    }
}

/**
 * Logout user
 */
function logout_user()
{
    session_start();
    session_unset();
    session_destroy();
    header('Location: /HealthGuard/login.php');
    exit();
}

/**
 * Get current user ID
 */
function get_user_id()
{
    return $_SESSION['user_id'] ?? null;
}

/**
 * Get current user name
 */
function get_user_name()
{
    return $_SESSION['user_name'] ?? 'Guest';
}

/**
 * Get current user role
 */
function get_user_role()
{
    return $_SESSION['user_role'] ?? null;
}

/**
 * Request password reset - Generate token and send email
 */
function request_password_reset($email)
{
    global $pdo;

    // Check if email exists
    $stmt = $pdo->prepare("SELECT id, name FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user) {
        // Don't reveal if email exists or not for security
        return ['success' => true, 'message' => 'If the email exists, a reset link has been sent'];
    }

    // Generate secure random token
    $token = bin2hex(random_bytes(32));

    // Set expiration to 1 hour from now
    $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

    // Delete any existing tokens for this email
    $stmt = $pdo->prepare("DELETE FROM password_resets WHERE email = ?");
    $stmt->execute([$email]);

    // Insert new token
    $stmt = $pdo->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
    $stmt->execute([$email, $token, $expires_at]);

    // Create reset link
    $reset_link = "http://" . $_SERVER['HTTP_HOST'] . "/HealthGuard/reset_password.php?token=" . $token;

    // Send email
    require_once __DIR__ . '/functions.php';

    $subject = "Password Reset Request - HealthGuard";
    $message = "
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
            .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .footer { text-align: center; margin-top: 20px; color: #6b7280; font-size: 14px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🛡️ HealthGuard</h1>
                <p>Password Reset Request</p>
            </div>
            <div class='content'>
                <p>Hello {$user['name']},</p>
                <p>We received a request to reset your password. Click the button below to create a new password:</p>
                <p style='text-align: center;'>
                    <a href='{$reset_link}' class='button'>Reset Password</a>
                </p>
                <p>Or copy and paste this link into your browser:</p>
                <p style='word-break: break-all; color: #667eea;'>{$reset_link}</p>
                <p><strong>This link will expire in 1 hour.</strong></p>
                <p>If you didn't request this password reset, please ignore this email. Your password will remain unchanged.</p>
            </div>
            <div class='footer'>
                <p>HealthGuard - Your Health, Your Priority</p>
            </div>
        </div>
    </body>
    </html>
    ";

    send_email($email, $subject, $message);

    return ['success' => true, 'message' => 'If the email exists, a reset link has been sent'];
}

/**
 * Verify reset token
 */
function verify_reset_token($token)
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM password_resets WHERE token = ? AND expires_at > NOW()");
    $stmt->execute([$token]);
    $reset = $stmt->fetch();

    if (!$reset) {
        return ['success' => false, 'message' => 'Invalid or expired reset token'];
    }

    return ['success' => true, 'email' => $reset['email']];
}

/**
 * Reset password with token
 */
function reset_password($token, $new_password)
{
    global $pdo;

    // Verify token
    $verification = verify_reset_token($token);
    if (!$verification['success']) {
        return $verification;
    }

    $email = $verification['email'];

    // Hash new password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update user password
    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
    $stmt->execute([$hashed_password, $email]);

    // Delete used token
    $stmt = $pdo->prepare("DELETE FROM password_resets WHERE token = ?");
    $stmt->execute([$token]);

    return ['success' => true, 'message' => 'Password has been reset successfully'];
}
