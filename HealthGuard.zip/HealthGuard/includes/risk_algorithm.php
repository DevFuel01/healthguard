<?php
// Disease Risk Assessment Algorithm
// HealthGuard - Disease Prevention & Monitoring System

require_once __DIR__ . '/../config/database.php';

/**
 * Calculate disease risk based on vitals
 * 
 * @param int $systolic Blood pressure systolic
 * @param int $diastolic Blood pressure diastolic
 * @param int $heart_rate Heart rate (bpm)
 * @param float $sugar_level Blood sugar level (mg/dL)
 * @param float $temperature Body temperature (°C)
 * @return array Risk assessment data
 */
function calculate_risk($systolic, $diastolic, $heart_rate, $sugar_level, $temperature)
{
    $risk_factors = [];
    $risk_score = 0;
    $recommendations = [];

    // Blood Pressure Assessment
    if ($systolic >= 140 || $diastolic >= 90) {
        $risk_factors[] = 'High blood pressure (Hypertension)';
        $risk_score += 3;
        $recommendations[] = 'Consult a doctor about your blood pressure';
        $recommendations[] = 'Reduce salt intake and increase physical activity';
    } elseif ($systolic >= 130 || $diastolic >= 85) {
        $risk_factors[] = 'Slightly elevated blood pressure';
        $risk_score += 2;
        $recommendations[] = 'Monitor blood pressure regularly';
        $recommendations[] = 'Maintain a healthy diet and exercise routine';
    } elseif ($systolic < 90 || $diastolic < 60) {
        $risk_factors[] = 'Low blood pressure (Hypotension)';
        $risk_score += 1;
        $recommendations[] = 'Stay hydrated and eat regular meals';
    } else {
        $risk_factors[] = 'Normal blood pressure';
    }

    // Heart Rate Assessment
    if ($heart_rate > 100) {
        $risk_factors[] = 'High heart rate (Tachycardia)';
        $risk_score += 2;
        $recommendations[] = 'Reduce caffeine and stress levels';
        $recommendations[] = 'Practice relaxation techniques';
    } elseif ($heart_rate < 60) {
        $risk_factors[] = 'Low heart rate (Bradycardia)';
        $risk_score += 1;
        $recommendations[] = 'Monitor heart rate regularly';
    } elseif ($heart_rate >= 80 && $heart_rate <= 90) {
        $risk_factors[] = 'Slightly elevated heart rate';
        $risk_score += 1;
    } else {
        $risk_factors[] = 'Normal heart rate';
    }

    // Blood Sugar Assessment
    if ($sugar_level >= 126) {
        $risk_factors[] = 'High sugar level (Diabetes risk)';
        $risk_score += 3;
        $recommendations[] = 'URGENT: Consult a healthcare provider for diabetes screening';
        $recommendations[] = 'Reduce sugar and carbohydrate intake';
        $recommendations[] = 'Increase physical activity';
    } elseif ($sugar_level >= 100) {
        $risk_factors[] = 'Elevated sugar level (Pre-diabetes)';
        $risk_score += 2;
        $recommendations[] = 'Monitor blood sugar levels closely';
        $recommendations[] = 'Adopt a low-sugar, balanced diet';
    } elseif ($sugar_level < 70) {
        $risk_factors[] = 'Low sugar level (Hypoglycemia)';
        $risk_score += 2;
        $recommendations[] = 'Eat regular meals and healthy snacks';
        $recommendations[] = 'Consult a doctor if symptoms persist';
    } else {
        $risk_factors[] = 'Normal sugar level';
    }

    // Temperature Assessment
    if ($temperature >= 38.0) {
        $risk_factors[] = 'Elevated temperature (Fever)';
        $risk_score += 2;
        $recommendations[] = 'Monitor temperature regularly';
        $recommendations[] = 'Stay hydrated and rest';
        $recommendations[] = 'Consult a doctor if fever persists';
    } elseif ($temperature >= 37.5) {
        $risk_factors[] = 'Slightly elevated temperature';
        $risk_score += 1;
        $recommendations[] = 'Monitor for other symptoms';
    } elseif ($temperature < 36.0) {
        $risk_factors[] = 'Low temperature (Hypothermia risk)';
        $risk_score += 2;
        $recommendations[] = 'Warm up gradually and seek medical attention';
    } else {
        $risk_factors[] = 'Normal temperature';
    }

    // Determine overall risk level
    if ($risk_score >= 6) {
        $risk_level = 'High';
        array_unshift($recommendations, 'URGENT: Consult a healthcare provider immediately');
    } elseif ($risk_score >= 3) {
        $risk_level = 'Medium';
        array_unshift($recommendations, 'Schedule a check-up with your doctor soon');
    } else {
        $risk_level = 'Low';
        $recommendations = ['Maintain healthy lifestyle', 'Continue regular exercise and balanced diet', 'Keep monitoring your vitals regularly'];
    }

    return [
        'risk_level' => $risk_level,
        'risk_score' => $risk_score,
        'risk_factors' => implode(', ', $risk_factors),
        'recommendations' => implode('. ', $recommendations) . '.'
    ];
}

/**
 * Save risk assessment to database
 */
function save_risk_assessment($user_id, $vital_id, $risk_data)
{
    global $pdo;

    $stmt = $pdo->prepare("
        INSERT INTO risk_assessments (user_id, vital_id, risk_level, risk_factors, recommendations) 
        VALUES (?, ?, ?, ?, ?)
    ");

    return $stmt->execute([
        $user_id,
        $vital_id,
        $risk_data['risk_level'],
        $risk_data['risk_factors'],
        $risk_data['recommendations']
    ]);
}

/**
 * Process vitals and create risk assessment
 */
function process_vitals_submission($user_id, $systolic, $diastolic, $heart_rate, $sugar_level, $temperature)
{
    global $pdo;

    try {
        // Insert vitals
        $stmt = $pdo->prepare("
            INSERT INTO vitals (user_id, blood_pressure_systolic, blood_pressure_diastolic, heart_rate, sugar_level, temperature) 
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$user_id, $systolic, $diastolic, $heart_rate, $sugar_level, $temperature]);
        $vital_id = $pdo->lastInsertId();

        // Calculate risk
        $risk_data = calculate_risk($systolic, $diastolic, $heart_rate, $sugar_level, $temperature);

        // Save risk assessment
        save_risk_assessment($user_id, $vital_id, $risk_data);

        // Gamification: Award points and update streak
        require_once __DIR__ . '/functions.php';

        // Award points for submitting vitals
        award_points($user_id, 10, 'Vitals submission');

        // Update streak
        $streak = update_streak($user_id);

        // Bonus points for maintaining streak
        if ($streak >= 7) {
            award_points($user_id, 5, '7-day streak bonus');
        }
        if ($streak >= 30) {
            award_points($user_id, 20, '30-day streak bonus');
        }

        // Send notification if high risk
        if ($risk_data['risk_level'] === 'High') {
            require_once __DIR__ . '/functions.php';
            create_notification(
                $user_id,
                'High Risk Alert',
                'Your recent vitals indicate high risk. Please consult a healthcare provider immediately.',
                'alert'
            );
        }

        return [
            'success' => true,
            'vital_id' => $vital_id,
            'risk_data' => $risk_data
        ];
    } catch (PDOException $e) {
        return [
            'success' => false,
            'message' => 'Failed to save vitals: ' . $e->getMessage()
        ];
    }
}
