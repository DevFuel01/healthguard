<?php
// Utility Functions
// HealthGuard - Disease Prevention & Monitoring System

require_once __DIR__ . '/../config/database.php';

/**
 * Sanitize input to prevent XSS
 */
function sanitize_input($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Format date for display
 */
function format_date($date)
{
    return date('M d, Y', strtotime($date));
}

/**
 * Format datetime for display
 */
function format_datetime($datetime)
{
    return date('M d, Y g:i A', strtotime($datetime));
}

/**
 * Get user by ID
 */
function get_user_by_id($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

/**
 * Get all users
 */
function get_all_users()
{
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM users WHERE role = 'user' ORDER BY created_at DESC");
    return $stmt->fetchAll();
}

/**
 * Get user vitals with pagination
 */
function get_user_vitals($user_id, $limit = null, $offset = 0)
{
    global $pdo;
    $sql = "SELECT * FROM vitals WHERE user_id = ? ORDER BY recorded_at DESC";

    if ($limit !== null) {
        $sql .= " LIMIT " . intval($limit);
        if ($offset > 0) {
            $sql .= " OFFSET " . intval($offset);
        }
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

/**
 * Get total count of user vitals for pagination
 */
function get_total_user_vitals_count($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM vitals WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch();
    return $result ? $result['count'] : 0;
}

/**
 * Get latest vital for user
 */
function get_latest_vital($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM vitals WHERE user_id = ? ORDER BY recorded_at DESC LIMIT 1");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

/**
 * Get latest risk assessment for user
 */
function get_latest_risk($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM risk_assessments WHERE user_id = ? ORDER BY assessed_at DESC LIMIT 1");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

/**
 * Get user notifications
 */
function get_user_notifications($user_id, $limit = 5)
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? OR user_id IS NULL ORDER BY created_at DESC LIMIT ?");
    $stmt->execute([$user_id, $limit]);
    return $stmt->fetchAll();
}

/**
 * Get unread notification count
 */
function get_unread_count($user_id)
{
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notifications WHERE (user_id = ? OR user_id IS NULL) AND is_read = 0");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch();
    return $result['count'];
}

/**
 * Create notification
 */
function create_notification($user_id, $title, $message, $type = 'info')
{
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$user_id, $title, $message, $type]);
}

/**
 * Get total users count
 */
function get_total_users()
{
    global $pdo;
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'user'");
    $result = $stmt->fetch();
    return $result['count'];
}

/**
 * Get high risk users count
 */
function get_high_risk_count()
{
    global $pdo;
    // Count users whose *latest* risk assessment is 'High'
    // This requires a subquery to get the latest assessment for each user
    $sql = "SELECT COUNT(*) as count 
            FROM risk_assessments ra1
            JOIN (
                SELECT user_id, MAX(assessed_at) as max_date
                FROM risk_assessments
                GROUP BY user_id
            ) ra2 ON ra1.user_id = ra2.user_id AND ra1.assessed_at = ra2.max_date
            WHERE ra1.risk_level = 'High'";

    $stmt = $pdo->query($sql);
    $result = $stmt->fetch();
    return $result['count'];
}

/**
 * Get recent vitals submissions
 */
function get_recent_vitals($limit = 10)
{
    global $pdo;
    $stmt = $pdo->prepare("
        SELECT v.*, u.name as user_name 
        FROM vitals v 
        JOIN users u ON v.user_id = u.id 
        ORDER BY v.recorded_at DESC 
        LIMIT ?
    ");
    $stmt->execute([$limit]);
    return $stmt->fetchAll();
}

/**
 * Get risk level color
 */
function get_risk_color($risk_level)
{
    switch ($risk_level) {
        case 'Low':
            return '#10b981'; // Green
        case 'Medium':
            return '#f59e0b'; // Yellow/Orange
        case 'High':
            return '#ef4444'; // Red
        default:
            return '#6b7280'; // Gray
    }
}

/**
 * Get risk level badge HTML
 */
function get_risk_badge($risk_level)
{
    $color = get_risk_color($risk_level);
    return "<span class='risk-badge' style='background-color: {$color};'>{$risk_level}</span>";
}

/**
 * Send email using PHP mail function
 */
function send_email($to, $subject, $message, $from_name = 'HealthGuard')
{
    $from_email = 'noreply@healthguard.com';

    // Set headers for HTML email
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: {$from_name} <{$from_email}>" . "\r\n";
    $headers .= "Reply-To: {$from_email}" . "\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();

    // Send email
    return mail($to, $subject, $message, $headers);
}

/**
 * Upload profile picture
 */
function upload_profile_picture($user_id, $file)
{
    global $pdo;

    // Validate file was uploaded
    if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
        return ['success' => false, 'message' => 'No file uploaded'];
    }

    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'File upload error'];
    }

    // Validate file size (max 2MB)
    $max_size = 2 * 1024 * 1024; // 2MB in bytes
    if ($file['size'] > $max_size) {
        return ['success' => false, 'message' => 'File size exceeds 2MB limit'];
    }

    // Validate file type
    $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime_type, $allowed_types)) {
        return ['success' => false, 'message' => 'Invalid file type. Only JPG, PNG, and GIF are allowed'];
    }

    // Get file extension
    $extension = '';
    switch ($mime_type) {
        case 'image/jpeg':
        case 'image/jpg':
            $extension = 'jpg';
            break;
        case 'image/png':
            $extension = 'png';
            break;
        case 'image/gif':
            $extension = 'gif';
            break;
    }

    // Generate unique filename
    $filename = 'user_' . $user_id . '_' . time() . '.' . $extension;
    $upload_dir = __DIR__ . '/../uploads/profiles/';
    $upload_path = $upload_dir . $filename;
    $relative_path = 'uploads/profiles/' . $filename;

    // Delete old profile picture if exists
    $user = get_user_by_id($user_id);
    if (!empty($user['profile_picture'])) {
        $old_file = __DIR__ . '/../' . $user['profile_picture'];
        if (file_exists($old_file) && $user['profile_picture'] !== 'uploads/profiles/default-avatar.png') {
            unlink($old_file);
        }
    }

    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
        return ['success' => false, 'message' => 'Failed to save uploaded file'];
    }

    // Update database
    try {
        $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
        $stmt->execute([$relative_path, $user_id]);
        return ['success' => true, 'message' => 'Profile picture uploaded successfully', 'path' => $relative_path];
    } catch (PDOException $e) {
        // Delete uploaded file if database update fails
        if (file_exists($upload_path)) {
            unlink($upload_path);
        }
        return ['success' => false, 'message' => 'Database update failed'];
    }
}

/**
 * Delete profile picture
 */
function delete_profile_picture($user_id)
{
    global $pdo;

    $user = get_user_by_id($user_id);

    if (!empty($user['profile_picture']) && $user['profile_picture'] !== 'uploads/profiles/default-avatar.png') {
        $file_path = __DIR__ . '/../' . $user['profile_picture'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }

    // Update database
    try {
        $stmt = $pdo->prepare("UPDATE users SET profile_picture = NULL WHERE id = ?");
        $stmt->execute([$user_id]);
        return ['success' => true, 'message' => 'Profile picture removed successfully'];
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Failed to remove profile picture'];
    }
}

/**
 * Get profile picture URL
 */
function get_profile_picture_url($user)
{
    if (!empty($user['profile_picture'])) {
        return '../' . $user['profile_picture'];
    }
    return '../uploads/profiles/default-avatar.png';
}

/**
 * Delete user account
 */
function delete_user($user_id)
{
    global $pdo;

    try {
        // Get user's profile picture before deletion
        $user = get_user_by_id($user_id);

        // Delete profile picture file if exists
        if (!empty($user['profile_picture']) && $user['profile_picture'] !== 'uploads/profiles/default-avatar.png') {
            $file_path = __DIR__ . '/../' . $user['profile_picture'];
            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }

        // Delete user (cascade will handle vitals, risk_assessments, notifications)
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'user'");
        $stmt->execute([$user_id]);

        if ($stmt->rowCount() > 0) {
            return ['success' => true, 'message' => 'User deleted successfully'];
        } else {
            return ['success' => false, 'message' => 'User not found or cannot delete admin'];
        }
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Failed to delete user: ' . $e->getMessage()];
    }
}

/**
 * Update user information
 */
function update_user($user_id, $name, $email, $age, $gender, $location)
{
    global $pdo;

    try {
        // Check if email is already taken by another user
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $user_id]);
        if ($stmt->fetch()) {
            return ['success' => false, 'message' => 'Email already in use by another user'];
        }

        // Update user
        $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, age = ?, gender = ?, location = ? WHERE id = ? AND role = 'user'");
        $stmt->execute([$name, $email, $age, $gender, $location, $user_id]);

        if ($stmt->rowCount() > 0) {
            return ['success' => true, 'message' => 'User updated successfully'];
        } else {
            return ['success' => false, 'message' => 'No changes made or user not found'];
        }
    } catch (PDOException $e) {
        return ['success' => false, 'message' => 'Failed to update user: ' . $e->getMessage()];
    }
}

/**
 * Get or create user stats
 */
function get_user_stats($user_id)
{
    global $pdo;

    $stmt = $pdo->prepare("SELECT * FROM user_stats WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $stats = $stmt->fetch();

    // Create stats if they don't exist
    if (!$stats) {
        $stmt = $pdo->prepare("INSERT INTO user_stats (user_id) VALUES (?)");
        $stmt->execute([$user_id]);
        return get_user_stats($user_id);
    }

    return $stats;
}

/**
 * Award points to user
 */
function award_points($user_id, $points, $reason = '')
{
    global $pdo;

    $stats = get_user_stats($user_id);
    $new_total = $stats['total_points'] + $points;
    $new_level = calculate_level($new_total);

    $stmt = $pdo->prepare("UPDATE user_stats SET total_points = ?, level = ? WHERE user_id = ?");
    $stmt->execute([$new_total, $new_level, $user_id]);

    // Check for achievements
    check_achievements($user_id);

    return $new_total;
}

/**
 * Calculate level based on points
 */
function calculate_level($points)
{
    // Level up every 100 points
    return floor($points / 100) + 1;
}

/**
 * Update streak tracking
 */
function update_streak($user_id)
{
    global $pdo;

    $stats = get_user_stats($user_id);
    $today = date('Y-m-d');
    $last_check_in = $stats['last_check_in'];

    if ($last_check_in === $today) {
        // Already checked in today
        return $stats['current_streak'];
    }

    $yesterday = date('Y-m-d', strtotime('-1 day'));

    if ($last_check_in === $yesterday) {
        // Consecutive day - increment streak
        $new_streak = $stats['current_streak'] + 1;
    } else {
        // Streak broken - reset to 1
        $new_streak = 1;
    }

    $longest_streak = max($new_streak, $stats['longest_streak']);

    $stmt = $pdo->prepare("UPDATE user_stats SET current_streak = ?, longest_streak = ?, last_check_in = ? WHERE user_id = ?");
    $stmt->execute([$new_streak, $longest_streak, $today, $user_id]);

    // Check for streak achievements
    check_achievements($user_id);

    return $new_streak;
}

/**
 * Check and award achievements
 */
function check_achievements($user_id)
{
    global $pdo;

    $stats = get_user_stats($user_id);

    // Get total vitals count
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM vitals WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $vitals_count = $stmt->fetch()['count'];

    // Get all achievements
    $achievements = $pdo->query("SELECT * FROM achievements")->fetchAll();

    foreach ($achievements as $achievement) {
        // Check if already earned
        $stmt = $pdo->prepare("SELECT id FROM user_achievements WHERE user_id = ? AND achievement_id = ?");
        $stmt->execute([$user_id, $achievement['id']]);

        if ($stmt->fetch()) {
            continue; // Already earned
        }

        // Check if requirements are met
        $earned = true;

        if ($achievement['points_required'] > 0 && $stats['total_points'] < $achievement['points_required']) {
            $earned = false;
        }

        if ($achievement['streak_required'] > 0 && $stats['current_streak'] < $achievement['streak_required']) {
            $earned = false;
        }

        if ($achievement['vitals_required'] > 0 && $vitals_count < $achievement['vitals_required']) {
            $earned = false;
        }

        // Award achievement
        if ($earned) {
            $stmt = $pdo->prepare("INSERT INTO user_achievements (user_id, achievement_id) VALUES (?, ?)");
            $stmt->execute([$user_id, $achievement['id']]);

            // Create notification
            create_notification(
                $user_id,
                'Achievement Unlocked! ' . $achievement['icon'],
                'You earned the "' . $achievement['name'] . '" badge! ' . $achievement['description'],
                'info'
            );
        }
    }
}

/**
 * Get user achievements
 */
function get_user_achievements($user_id)
{
    global $pdo;

    $stmt = $pdo->prepare("
        SELECT a.*, ua.earned_at 
        FROM user_achievements ua 
        JOIN achievements a ON ua.achievement_id = a.id 
        WHERE ua.user_id = ? 
        ORDER BY ua.earned_at DESC
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}
