-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 25, 2025 at 01:11 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthguard`
--
CREATE DATABASE IF NOT EXISTS healthguard;
USE healthguard;

-- --------------------------------------------------------

--
-- Table structure for table `achievements`
--

CREATE TABLE `achievements` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `icon` varchar(50) NOT NULL,
  `points_required` int(11) DEFAULT 0,
  `streak_required` int(11) DEFAULT 0,
  `vitals_required` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `achievements`
--

INSERT INTO `achievements` (`id`, `name`, `description`, `icon`, `points_required`, `streak_required`, `vitals_required`, `created_at`) VALUES
(1, 'First Steps', 'Submit your first vitals reading', '🎯', 0, 0, 1, '2025-12-25 06:48:32'),
(2, 'Health Warrior', 'Maintain a 7-day streak', '🔥', 0, 7, 0, '2025-12-25 06:48:32'),
(3, 'Consistency King', 'Maintain a 30-day streak', '👑', 0, 30, 0, '2025-12-25 06:48:32'),
(4, 'Century Club', 'Earn 100 points', '💯', 100, 0, 0, '2025-12-25 06:48:32'),
(5, 'Health Champion', 'Earn 500 points', '🏆', 500, 0, 0, '2025-12-25 06:48:32'),
(6, 'Vital Tracker', 'Submit 10 vitals readings', '📊', 0, 0, 10, '2025-12-25 06:48:32'),
(7, 'Health Master', 'Submit 50 vitals readings', '⭐', 0, 0, 50, '2025-12-25 06:48:32'),
(8, 'Wellness Guru', 'Reach Level 5', '🌟', 0, 0, 0, '2025-12-25 06:48:32'),
(9, 'Perfect Week', 'Submit vitals every day for a week', '✨', 0, 7, 7, '2025-12-25 06:48:32'),
(10, 'Health Legend', 'Earn 1000 points', '🎖️', 1000, 0, 0, '2025-12-25 06:48:32');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','warning','alert','tip') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, NULL, 'Welcome to HealthGuard', 'Track your vitals daily for better health monitoring and disease prevention.', 'info', 0, '2025-12-25 05:08:41'),
(2, 2, 'Daily Health Tip', 'Drink at least 8 glasses of water daily to maintain optimal health.', 'tip', 0, '2025-12-25 05:08:41'),
(3, 3, 'Great Progress!', 'Your vitals are looking excellent. Keep maintaining your healthy lifestyle.', 'info', 1, '2025-12-25 05:08:41'),
(4, 4, 'High Risk Alert', 'Your recent vitals indicate high risk. Please consult a healthcare provider immediately.', 'alert', 0, '2025-12-25 05:08:41'),
(5, NULL, 'System Update', 'New features added: Export your vitals history and view detailed health trends.', 'info', 0, '2025-12-25 05:08:41'),
(6, NULL, 'Health Tip: Exercise', 'Regular physical activity for at least 30 minutes daily can reduce disease risk by 50%.', 'tip', 0, '2025-12-25 05:08:41'),
(7, NULL, 'Health Tip: Nutrition', 'A balanced diet rich in fruits and vegetables strengthens your immune system.', 'tip', 0, '2025-12-25 05:08:41'),
(8, NULL, 'Health Tip: Sleep', 'Quality sleep of 7-8 hours is essential for disease prevention and recovery.', 'tip', 0, '2025-12-25 05:08:41'),
(9, NULL, 'Health Tip: Stress', 'Managing stress through meditation or yoga can significantly improve heart health.', 'tip', 0, '2025-12-25 05:08:41'),
(10, NULL, 'Health Tip: Hydration', 'Proper hydration helps regulate body temperature and supports vital organ function.', 'tip', 0, '2025-12-25 05:08:41'),
(11, 5, 'See Doctor', 'See Doctor', 'tip', 0, '2025-12-25 05:31:05'),
(12, 5, 'Achievement Unlocked! 🎯', 'You earned the \"First Steps\" badge! Submit your first vitals reading', 'info', 0, '2025-12-25 06:57:05'),
(13, 5, 'Achievement Unlocked! 🌟', 'You earned the \"Wellness Guru\" badge! Reach Level 5', 'info', 0, '2025-12-25 06:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `token`, `expires_at`, `created_at`) VALUES
(1, 'ib@gmail.com', 'd8e427560c377c75b4b1406ec4e901d4f47b2737b6b59505023d2ff7133a135d', '2025-12-25 06:54:06', '2025-12-25 05:54:06'),
(2, 'john@example.com', '3d085b2cc402648a81b18cbafdc4ff8a028cb792780974984fdbef813b2226a4', '2025-12-25 06:57:14', '2025-12-25 05:57:14');

-- --------------------------------------------------------

--
-- Table structure for table `risk_assessments`
--

CREATE TABLE `risk_assessments` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vital_id` int(11) NOT NULL,
  `risk_level` enum('Low','Medium','High') NOT NULL,
  `risk_factors` text DEFAULT NULL,
  `recommendations` text DEFAULT NULL,
  `assessed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `risk_assessments`
--

INSERT INTO `risk_assessments` (`id`, `user_id`, `vital_id`, `risk_level`, `risk_factors`, `recommendations`, `assessed_at`) VALUES
(1, 2, 1, 'Low', 'Normal blood pressure, Normal heart rate, Normal sugar level, Normal temperature', 'Maintain healthy lifestyle. Continue regular exercise and balanced diet.', '2025-12-25 05:08:41'),
(2, 2, 5, 'Medium', 'Slightly elevated blood pressure, Elevated sugar level', 'Monitor blood pressure and sugar levels closely. Reduce salt and sugar intake. Increase physical activity.', '2025-12-25 05:08:41'),
(3, 3, 8, 'Low', 'Normal blood pressure, Normal heart rate, Normal sugar level, Normal temperature', 'Excellent vitals! Keep up the good work with your current health routine.', '2025-12-25 05:08:41'),
(4, 4, 13, 'High', 'High blood pressure (Hypertension), High heart rate, High sugar level (Diabetes risk), Elevated temperature', 'URGENT: Consult a healthcare provider immediately. High risk of cardiovascular disease and diabetes. Medication may be required.', '2025-12-25 05:08:41'),
(5, 5, 18, 'Medium', 'Normal blood pressure, Normal heart rate, Low sugar level (Hypoglycemia), Low temperature (Hypothermia risk)', 'Schedule a check-up with your doctor soon. Eat regular meals and healthy snacks. Consult a doctor if symptoms persist. Warm up gradually and seek medical attention.', '2025-12-25 05:14:31'),
(6, 5, 19, 'Low', 'Normal blood pressure, Normal heart rate, Normal sugar level, Normal temperature', 'Maintain healthy lifestyle. Continue regular exercise and balanced diet. Keep monitoring your vitals regularly.', '2025-12-25 06:57:04'),
(7, 5, 20, 'Low', 'Normal blood pressure, Normal heart rate, Normal sugar level, Normal temperature', 'Maintain healthy lifestyle. Continue regular exercise and balanced diet. Keep monitoring your vitals regularly.', '2025-12-25 06:57:22'),
(8, 5, 21, 'Low', 'Normal blood pressure, Normal heart rate, Normal sugar level, Normal temperature', 'Maintain healthy lifestyle. Continue regular exercise and balanced diet. Keep monitoring your vitals regularly.', '2025-12-25 06:57:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') DEFAULT 'user',
  `age` int(11) DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `age`, `gender`, `location`, `profile_picture`, `created_at`, `updated_at`) VALUES
(1, 'Admin User', 'admin@healthguard.com', '$2y$10$wx1RryoiML0kyJ0YtXtbH.WYQBclWspqdNljIh8WB5RoqcUkcpiku', 'admin', 35, 'male', 'Lagos, Nigeria', NULL, '2025-12-25 05:08:41', '2025-12-25 05:20:11'),
(2, 'John Doe', 'john@example.com', '$2y$10$wx1RryoiML0kyJ0YtXtbH.WYQBclWspqdNljIh8WB5RoqcUkcpiku', 'user', 28, 'male', 'Abuja, Nigeria', NULL, '2025-12-25 05:08:41', '2025-12-25 05:23:31'),
(3, 'Jane Smith', 'jane@example.com', '$2y$10$wx1RryoiML0kyJ0YtXtbH.WYQBclWspqdNljIh8WB5RoqcUkcpiku', 'user', 32, 'female', 'Port Harcourt, Nigeria', NULL, '2025-12-25 05:08:41', '2025-12-25 05:23:36'),
(4, 'Michael Johnson', 'michael@example.com', '$2y$10$wx1RryoiML0kyJ0YtXtbH.WYQBclWspqdNljIh8WB5RoqcUkcpiku', 'user', 45, 'male', 'Kano, Nigeria', NULL, '2025-12-25 05:08:41', '2025-12-25 05:23:43'),
(5, 'Idris Ibrahim', 'ib1@gmail.com', '$2y$10$zDB.lLSOUky/uDB91ZpbA.AfO4HDrpiu3iEfjuGAuyzCR1v5sbStm', 'user', 31, 'male', 'Jos', 'uploads/profiles/user_5_1766643288.png', '2025-12-25 05:12:05', '2025-12-25 06:32:54');

-- --------------------------------------------------------

--
-- Table structure for table `user_achievements`
--

CREATE TABLE `user_achievements` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `achievement_id` int(11) NOT NULL,
  `earned_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_achievements`
--

INSERT INTO `user_achievements` (`id`, `user_id`, `achievement_id`, `earned_at`) VALUES
(1, 5, 1, '2025-12-25 06:57:05'),
(2, 5, 8, '2025-12-25 06:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `user_stats`
--

CREATE TABLE `user_stats` (
  `user_id` int(11) NOT NULL,
  `total_points` int(11) DEFAULT 0,
  `current_streak` int(11) DEFAULT 0,
  `longest_streak` int(11) DEFAULT 0,
  `last_check_in` date DEFAULT NULL,
  `level` int(11) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_stats`
--

INSERT INTO `user_stats` (`user_id`, `total_points`, `current_streak`, `longest_streak`, `last_check_in`, `level`, `created_at`, `updated_at`) VALUES
(2, 0, 0, 0, NULL, 1, '2025-12-25 06:48:32', '2025-12-25 06:48:32'),
(3, 0, 0, 0, NULL, 1, '2025-12-25 06:48:32', '2025-12-25 06:48:32'),
(4, 0, 0, 0, NULL, 1, '2025-12-25 06:48:32', '2025-12-25 06:48:32'),
(5, 30, 1, 1, '2025-12-25', 1, '2025-12-25 06:48:32', '2025-12-25 06:57:49');

-- --------------------------------------------------------

--
-- Table structure for table `vitals`
--

CREATE TABLE `vitals` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `blood_pressure_systolic` int(11) NOT NULL,
  `blood_pressure_diastolic` int(11) NOT NULL,
  `heart_rate` int(11) NOT NULL,
  `sugar_level` decimal(5,2) NOT NULL,
  `temperature` decimal(4,2) NOT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vitals`
--

INSERT INTO `vitals` (`id`, `user_id`, `blood_pressure_systolic`, `blood_pressure_diastolic`, `heart_rate`, `sugar_level`, `temperature`, `recorded_at`) VALUES
(1, 2, 120, 80, 72, 95.50, 36.80, '2025-12-18 05:08:41'),
(2, 2, 125, 82, 75, 98.20, 37.00, '2025-12-19 05:08:41'),
(3, 2, 118, 78, 70, 92.00, 36.70, '2025-12-20 05:08:41'),
(4, 2, 122, 81, 73, 96.50, 36.90, '2025-12-21 05:08:41'),
(5, 2, 130, 85, 78, 105.00, 37.20, '2025-12-22 05:08:41'),
(6, 2, 128, 84, 76, 102.50, 37.10, '2025-12-23 05:08:41'),
(7, 2, 124, 82, 74, 97.80, 36.80, '2025-12-24 05:08:41'),
(8, 3, 115, 75, 68, 88.50, 36.60, '2025-12-18 05:08:41'),
(9, 3, 118, 76, 70, 90.20, 36.70, '2025-12-19 05:08:41'),
(10, 3, 116, 74, 69, 89.00, 36.50, '2025-12-20 05:08:41'),
(11, 3, 120, 78, 72, 92.50, 36.80, '2025-12-21 05:08:41'),
(12, 3, 117, 75, 70, 91.00, 36.60, '2025-12-22 05:08:41'),
(13, 4, 145, 95, 88, 145.50, 37.80, '2025-12-18 05:08:41'),
(14, 4, 150, 98, 92, 152.00, 38.00, '2025-12-19 05:08:41'),
(15, 4, 148, 96, 90, 148.50, 37.90, '2025-12-20 05:08:41'),
(16, 4, 152, 100, 95, 155.00, 38.20, '2025-12-21 05:08:41'),
(17, 4, 155, 102, 98, 160.50, 38.50, '2025-12-22 05:08:41'),
(18, 5, 110, 70, 68, 60.00, 34.00, '2025-12-25 05:14:31'),
(19, 5, 120, 80, 75, 90.00, 37.00, '2025-12-25 06:57:04'),
(20, 5, 120, 80, 75, 90.00, 37.00, '2025-12-25 06:57:22'),
(21, 5, 120, 80, 75, 90.00, 37.00, '2025-12-25 06:57:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `achievements`
--
ALTER TABLE `achievements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_is_read` (`is_read`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_token` (`token`),
  ADD KEY `idx_expires_at` (`expires_at`);

--
-- Indexes for table `risk_assessments`
--
ALTER TABLE `risk_assessments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vital_id` (`vital_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_risk_level` (`risk_level`),
  ADD KEY `idx_assessed_at` (`assessed_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_role` (`role`);

--
-- Indexes for table `user_achievements`
--
ALTER TABLE `user_achievements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_achievement` (`user_id`,`achievement_id`),
  ADD KEY `achievement_id` (`achievement_id`);

--
-- Indexes for table `user_stats`
--
ALTER TABLE `user_stats`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `vitals`
--
ALTER TABLE `vitals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_recorded_at` (`recorded_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `achievements`
--
ALTER TABLE `achievements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `risk_assessments`
--
ALTER TABLE `risk_assessments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_achievements`
--
ALTER TABLE `user_achievements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `vitals`
--
ALTER TABLE `vitals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `risk_assessments`
--
ALTER TABLE `risk_assessments`
  ADD CONSTRAINT `risk_assessments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `risk_assessments_ibfk_2` FOREIGN KEY (`vital_id`) REFERENCES `vitals` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_achievements`
--
ALTER TABLE `user_achievements`
  ADD CONSTRAINT `user_achievements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_achievements_ibfk_2` FOREIGN KEY (`achievement_id`) REFERENCES `achievements` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_stats`
--
ALTER TABLE `user_stats`
  ADD CONSTRAINT `user_stats_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vitals`
--
ALTER TABLE `vitals`
  ADD CONSTRAINT `vitals_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
