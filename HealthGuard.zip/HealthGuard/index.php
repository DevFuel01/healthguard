<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HealthGuard - Disease Prevention & Monitoring</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="navbar-brand">🛡️ HealthGuard</div>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="navbar-nav" id="navbarNav">
                <li><a href="index.php" class="active">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php" class="btn btn-primary btn-sm">Get Started</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Hamburger menu toggle
        const hamburger = document.getElementById('hamburger');
        const navbarNav = document.getElementById('navbarNav');

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarNav.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            }
        });

        // Close menu when clicking on a link
        navbarNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            });
        });
    </script>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <h1 class="hero-title">Your Health, Your Priority</h1>
            <p class="hero-subtitle">Advanced disease prevention through intelligent health monitoring</p>
            <div class="hero-cta">
                <a href="signup.php" class="btn btn-primary" style="margin-right: 1rem;">Start Monitoring</a>
                <a href="login.php" class="btn btn-secondary">Sign In</a>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section style="padding: 3rem 0;">
        <div class="container">
            <div class="grid grid-3">
                <div class="card">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">📊</div>
                    <h3>Vitals Tracking</h3>
                    <p class="text-muted">Monitor blood pressure, heart rate, sugar levels, and temperature with interactive charts and historical data.</p>
                </div>

                <div class="card">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">🎯</div>
                    <h3>Risk Assessment</h3>
                    <p class="text-muted">AI-powered algorithm analyzes your vitals to calculate disease risk levels and provide personalized recommendations.</p>
                </div>

                <div class="card">
                    <div style="font-size: 3rem; margin-bottom: 1rem;">🔔</div>
                    <h3>Smart Alerts</h3>
                    <p class="text-muted">Receive instant notifications when vitals indicate high risk, plus daily health tips for disease prevention.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section style="padding: 3rem 0; background: var(--bg-secondary);">
        <div class="container">
            <h2 class="text-center" style="margin-bottom: 3rem;">How HealthGuard Works</h2>
            <div class="grid grid-4">
                <div class="text-center">
                    <div class="stat-value">1</div>
                    <h4>Sign Up</h4>
                    <p class="text-muted">Create your free account in seconds</p>
                </div>

                <div class="text-center">
                    <div class="stat-value">2</div>
                    <h4>Track Vitals</h4>
                    <p class="text-muted">Input your health measurements daily</p>
                </div>

                <div class="text-center">
                    <div class="stat-value">3</div>
                    <h4>Get Analysis</h4>
                    <p class="text-muted">Receive instant risk assessment</p>
                </div>

                <div class="text-center">
                    <div class="stat-value">4</div>
                    <h4>Stay Healthy</h4>
                    <p class="text-muted">Follow personalized recommendations</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section style="padding: 4rem 0;">
        <div class="container text-center">
            <h2 style="margin-bottom: 1rem;">Ready to Take Control of Your Health?</h2>
            <p class="text-muted" style="margin-bottom: 2rem; font-size: 1.125rem;">Join thousands monitoring their health with HealthGuard</p>
            <a href="signup.php" class="btn btn-primary" style="padding: 1rem 3rem; font-size: 1.125rem;">Get Started Free</a>
        </div>
    </section>

    <!-- Footer -->
    <footer style="background: var(--bg-secondary); padding: 2rem 0; margin-top: 4rem; border-top: 1px solid var(--border);">
        <div class="container text-center">
            <div class="navbar-brand" style="margin-bottom: 1rem;">🛡️ HealthGuard</div>
            <p class="text-muted">&copy; 2025 HealthGuard. Disease Prevention & Monitoring System.</p>
            <p class="text-muted" style="font-size: 0.875rem; margin-top: 0.5rem;">Built for Hackathon Excellence</p>
        </div>
    </footer>
</body>

</html>