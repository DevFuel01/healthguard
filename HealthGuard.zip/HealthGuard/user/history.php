<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

check_auth();
check_role('user');

$user_id = get_user_id();
$all_vitals = get_user_vitals($user_id);

// Pagination for Detailed History
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$total_vitals = get_total_user_vitals_count($user_id);
$total_pages = ceil($total_vitals / $per_page);
$offset = ($page - 1) * $per_page;

// Get vitals with risk assessments (paginated for the table)
$stmt = $pdo->prepare("
    SELECT v.*, r.risk_level, r.risk_factors, r.recommendations 
    FROM vitals v 
    LEFT JOIN risk_assessments r ON v.id = r.vital_id 
    WHERE v.user_id = ? 
    ORDER BY v.recorded_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute([$user_id, $per_page, $offset]);
$vitals_with_risk = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vitals History - HealthGuard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="dashboard.php" class="navbar-brand">🛡️ HealthGuard</a>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="navbar-nav" id="navbarNav">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="history.php" class="active">History</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Hamburger menu toggle
        const hamburger = document.getElementById('hamburger');
        const navbarNav = document.getElementById('navbarNav');

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarNav.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            }
        });

        // Close menu when clicking on a link
        navbarNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            });
        });
    </script>

    <!-- History Content -->
    <div class="dashboard">
        <div class="container">
            <div class="dashboard-header">
                <h1 class="dashboard-title">📊 Vitals History</h1>
                <p class="dashboard-subtitle">Track your health trends over time</p>
            </div>

            <!-- Charts -->
            <div class="grid grid-2" style="margin-bottom: 2rem;">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Blood Pressure Trend</h3>
                    </div>
                    <div class="card-body">
                        <canvas id="bpChart"></canvas>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Heart Rate Trend</h3>
                    </div>
                    <div class="card-body">
                        <canvas id="hrChart"></canvas>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Sugar Level Trend</h3>
                    </div>
                    <div class="card-body">
                        <canvas id="sugarChart"></canvas>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Temperature Trend</h3>
                    </div>
                    <div class="card-body">
                        <canvas id="tempChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Detailed History Table -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Detailed History</h3>
                </div>
                <div class="card-body">
                    <?php if (count($vitals_with_risk) > 0): ?>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Date & Time</th>
                                        <th>Blood Pressure</th>
                                        <th>Heart Rate</th>
                                        <th>Sugar Level</th>
                                        <th>Temperature</th>
                                        <th>Risk Level</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($vitals_with_risk as $vital): ?>
                                        <tr>
                                            <td><?php echo format_datetime($vital['recorded_at']); ?></td>
                                            <td><?php echo $vital['blood_pressure_systolic'] . '/' . $vital['blood_pressure_diastolic']; ?> mmHg</td>
                                            <td><?php echo $vital['heart_rate']; ?> bpm</td>
                                            <td><?php echo $vital['sugar_level']; ?> mg/dL</td>
                                            <td><?php echo $vital['temperature']; ?> °C</td>
                                            <td>
                                                <?php if ($vital['risk_level']): ?>
                                                    <span class="risk-badge risk-<?php echo strtolower($vital['risk_level']); ?>">
                                                        <?php echo $vital['risk_level']; ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="text-muted">N/A</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <?php if ($total_pages > 1): ?>
                            <div class="pagination" style="margin-top: 1.5rem; display: flex; justify-content: center; gap: 0.5rem; align-items: center;">
                                <?php if ($page > 1): ?>
                                    <a href="?page=<?php echo $page - 1; ?>" class="btn btn-secondary btn-sm">&laquo; Prev</a>
                                <?php endif; ?>

                                <?php
                                $start_page = max(1, $page - 2);
                                $end_page = min($total_pages, $page + 2);

                                if ($start_page > 1) {
                                    echo '<a href="?page=1" class="btn btn-secondary btn-sm">1</a>';
                                    if ($start_page > 2) echo '<span class="text-muted">...</span>';
                                }

                                for ($i = $start_page; $i <= $end_page; $i++): ?>
                                    <a href="?page=<?php echo $i; ?>" class="btn <?php echo $i === $page ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor;

                                if ($end_page < $total_pages) {
                                    if ($end_page < $total_pages - 1) echo '<span class="text-muted">...</span>';
                                    echo '<a href="?page=' . $total_pages . '" class="btn btn-secondary btn-sm">' . $total_pages . '</a>';
                                }
                                ?>

                                <?php if ($page < $total_pages): ?>
                                    <a href="?page=<?php echo $page + 1; ?>" class="btn btn-secondary btn-sm">Next &raquo;</a>
                                <?php endif; ?>
                            </div>
                            <div style="text-align: center; margin-top: 0.5rem;">
                                <small class="text-muted">Showing page <?php echo $page; ?> of <?php echo $total_pages; ?> (<?php echo $total_vitals; ?> total records)</small>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-muted text-center">No vitals recorded yet. Start tracking your health from the dashboard!</p>
                        <div style="text-align: center; margin-top: 1rem;">
                            <a href="dashboard.php" class="btn btn-primary">Go to Dashboard</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Prepare data for charts
        const vitalsData = <?php echo json_encode(array_reverse($all_vitals)); ?>;

        const labels = vitalsData.map(v => new Date(v.recorded_at).toLocaleDateString());
        const bpSystolic = vitalsData.map(v => v.blood_pressure_systolic);
        const bpDiastolic = vitalsData.map(v => v.blood_pressure_diastolic);
        const heartRate = vitalsData.map(v => v.heart_rate);
        const sugarLevel = vitalsData.map(v => v.sugar_level);
        const temperature = vitalsData.map(v => v.temperature);

        // Chart configuration
        const chartConfig = {
            type: 'line',
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        labels: {
                            color: '#cbd5e1'
                        }
                    }
                },
                scales: {
                    y: {
                        ticks: {
                            color: '#cbd5e1'
                        },
                        grid: {
                            color: 'rgba(148, 163, 184, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#cbd5e1'
                        },
                        grid: {
                            color: 'rgba(148, 163, 184, 0.1)'
                        }
                    }
                }
            }
        };

        // Blood Pressure Chart
        new Chart(document.getElementById('bpChart'), {
            ...chartConfig,
            data: {
                labels: labels,
                datasets: [{
                        label: 'Systolic',
                        data: bpSystolic,
                        borderColor: '#667eea',
                        backgroundColor: 'rgba(102, 126, 234, 0.1)',
                        tension: 0.4
                    },
                    {
                        label: 'Diastolic',
                        data: bpDiastolic,
                        borderColor: '#764ba2',
                        backgroundColor: 'rgba(118, 75, 162, 0.1)',
                        tension: 0.4
                    }
                ]
            }
        });

        // Heart Rate Chart
        new Chart(document.getElementById('hrChart'), {
            ...chartConfig,
            data: {
                labels: labels,
                datasets: [{
                    label: 'Heart Rate (bpm)',
                    data: heartRate,
                    borderColor: '#f093fb',
                    backgroundColor: 'rgba(240, 147, 251, 0.1)',
                    tension: 0.4
                }]
            }
        });

        // Sugar Level Chart
        new Chart(document.getElementById('sugarChart'), {
            ...chartConfig,
            data: {
                labels: labels,
                datasets: [{
                    label: 'Sugar Level (mg/dL)',
                    data: sugarLevel,
                    borderColor: '#f59e0b',
                    backgroundColor: 'rgba(245, 158, 11, 0.1)',
                    tension: 0.4
                }]
            }
        });

        // Temperature Chart
        new Chart(document.getElementById('tempChart'), {
            ...chartConfig,
            data: {
                labels: labels,
                datasets: [{
                    label: 'Temperature (°C)',
                    data: temperature,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4
                }]
            }
        });
    </script>
</body>

</html>