<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once '../includes/risk_algorithm.php';

check_auth();
check_role('user');

$user_id = get_user_id();
$user = get_user_by_id($user_id);
$latest_vital = get_latest_vital($user_id);
$latest_risk = get_latest_risk($user_id);
$notifications = get_user_notifications($user_id, 5);

// Pagination for Recent Vitals
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$total_vitals = get_total_user_vitals_count($user_id);
$total_pages = ceil($total_vitals / $per_page);
$offset = ($page - 1) * $per_page;
$recent_vitals = get_user_vitals($user_id, $per_page, $offset);

// Gamification data
$user_stats = get_user_stats($user_id);
$user_achievements = get_user_achievements($user_id);

// Handle vitals submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_vitals'])) {
    $systolic = intval($_POST['systolic']);
    $diastolic = intval($_POST['diastolic']);
    $heart_rate = intval($_POST['heart_rate']);
    $sugar_level = floatval($_POST['sugar_level']);
    $temperature = floatval($_POST['temperature']);

    $result = process_vitals_submission($user_id, $systolic, $diastolic, $heart_rate, $sugar_level, $temperature);

    if ($result['success']) {
        $message = '<div class="alert alert-success">Vitals submitted successfully! Risk Level: ' . $result['risk_data']['risk_level'] . '</div>';
        // Refresh data
        $latest_vital = get_latest_vital($user_id);
        $latest_risk = get_latest_risk($user_id);

        // Recalculate pagination after new submission
        $total_vitals = get_total_user_vitals_count($user_id);
        $total_pages = ceil($total_vitals / $per_page);
        $recent_vitals = get_user_vitals($user_id, $per_page, $offset);
    } else {
        $message = '<div class="alert alert-danger">' . htmlspecialchars($result['message']) . '</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - HealthGuard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="dashboard.php" class="navbar-brand">🛡️ HealthGuard</a>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="navbar-nav" id="navbarNav">
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Hamburger menu toggle
        const hamburger = document.getElementById('hamburger');
        const navbarNav = document.getElementById('navbarNav');

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarNav.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            }
        });

        // Close menu when clicking on a link
        navbarNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            });
        });
    </script>

    <!-- Dashboard Content -->
    <div class="dashboard">
        <div class="container">
            <!-- Header -->
            <div class="dashboard-header">
                <h1 class="dashboard-title">Welcome back, <?php echo htmlspecialchars($user['name']); ?>! 👋</h1>
                <p class="dashboard-subtitle">Monitor your health and stay informed</p>
            </div>

            <?php echo $message; ?>

            <!-- Current Risk Level -->
            <?php if ($latest_risk): ?>
                <div class="card" style="margin-bottom: 2rem; border-left: 4px solid <?php echo get_risk_color($latest_risk['risk_level']); ?>;">
                    <div class="d-flex justify-between align-center">
                        <div>
                            <h3>Current Risk Level</h3>
                            <p class="text-muted">Based on your latest vitals</p>
                        </div>
                        <div>
                            <span class="risk-badge risk-<?php echo strtolower($latest_risk['risk_level']); ?>">
                                <?php echo $latest_risk['risk_level']; ?> Risk
                            </span>
                        </div>
                    </div>

                    <?php if ($latest_risk['risk_level'] === 'High'): ?>
                        <div class="alert alert-danger" style="margin-top: 1rem;">
                            <strong>⚠️ Urgent:</strong> Your vitals indicate high risk. Please consult a healthcare provider immediately.
                        </div>
                    <?php endif; ?>

                    <div style="margin-top: 1rem;">
                        <strong>Recommendations:</strong>
                        <p class="text-muted"><?php echo htmlspecialchars($latest_risk['recommendations']); ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Quick Stats -->
            <div class="grid grid-4" style="margin-bottom: 2rem;">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $latest_vital ? $latest_vital['blood_pressure_systolic'] . '/' . $latest_vital['blood_pressure_diastolic'] : '--'; ?></div>
                    <div class="stat-label">Blood Pressure</div>
                </div>

                <div class="stat-card">
                    <div class="stat-value"><?php echo $latest_vital ? $latest_vital['heart_rate'] : '--'; ?></div>
                    <div class="stat-label">Heart Rate (bpm)</div>
                </div>

                <div class="stat-card">
                    <div class="stat-value"><?php echo $latest_vital ? $latest_vital['sugar_level'] : '--'; ?></div>
                    <div class="stat-label">Sugar Level (mg/dL)</div>
                </div>

                <div class="stat-card">
                    <div class="stat-value"><?php echo $latest_vital ? $latest_vital['temperature'] : '--'; ?></div>
                    <div class="stat-label">Temperature (°C)</div>
                </div>
            </div>

            <!-- Gamification Stats -->
            <div class="card" style="margin-bottom: 2rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
                <div class="card-header" style="border-bottom: 1px solid rgba(255,255,255,0.1);">
                    <h3 class="card-title" style="color: white;">🎮 Your Health Journey</h3>
                </div>
                <div class="card-body">
                    <div class="grid grid-4" style="margin-bottom: 1.5rem;">
                        <div style="text-align: center;">
                            <div style="font-size: 2rem; font-weight: bold; color: #ffd700;">⭐</div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: white;"><?php echo $user_stats['total_points']; ?></div>
                            <div style="font-size: 0.875rem; color: rgba(255,255,255,0.8);">Total Points</div>
                        </div>

                        <div style="text-align: center;">
                            <div style="font-size: 2rem; font-weight: bold; color: #ffd700;">🏆</div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: white;">Level <?php echo $user_stats['level']; ?></div>
                            <div style="font-size: 0.875rem; color: rgba(255,255,255,0.8);">Current Level</div>
                        </div>

                        <div style="text-align: center;">
                            <div style="font-size: 2rem; font-weight: bold; color: #ffd700;">🔥</div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: white;"><?php echo $user_stats['current_streak']; ?> Days</div>
                            <div style="font-size: 0.875rem; color: rgba(255,255,255,0.8);">Current Streak</div>
                        </div>

                        <div style="text-align: center;">
                            <div style="font-size: 2rem; font-weight: bold; color: #ffd700;">🎖️</div>
                            <div style="font-size: 1.5rem; font-weight: bold; color: white;"><?php echo count($user_achievements); ?></div>
                            <div style="font-size: 0.875rem; color: rgba(255,255,255,0.8);">Achievements</div>
                        </div>
                    </div>

                    <?php if (count($user_achievements) > 0): ?>
                        <div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 1rem;">
                            <h4 style="color: white; margin-bottom: 1rem; font-size: 1rem;">Recent Achievements</h4>
                            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                <?php foreach (array_slice($user_achievements, 0, 6) as $achievement): ?>
                                    <div style="background: rgba(255,255,255,0.1); padding: 0.5rem 1rem; border-radius: 20px; display: flex; align-items: center; gap: 0.5rem;" title="<?php echo htmlspecialchars($achievement['description']); ?>">
                                        <span style="font-size: 1.25rem;"><?php echo $achievement['icon']; ?></span>
                                        <span style="color: white; font-size: 0.875rem;"><?php echo htmlspecialchars($achievement['name']); ?></span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <div style="border-top: 1px solid rgba(255,255,255,0.1); padding-top: 1rem; text-align: center;">
                            <p style="color: rgba(255,255,255,0.8); margin: 0;">Submit your first vitals to start earning achievements! 🎯</p>
                        </div>
                    <?php endif; ?>

                    <div style="margin-top: 1rem; text-align: center;">
                        <small style="color: rgba(255,255,255,0.6);">
                            💡 Earn 10 points per vitals submission + streak bonuses!
                        </small>
                    </div>
                </div>
            </div>

            <div class="grid grid-2">
                <!-- Submit Vitals Form -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">📝 Submit Vitals</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="form-group">
                                <label class="form-label">Blood Pressure (mmHg)</label>
                                <div class="form-row">
                                    <input type="number" name="systolic" class="form-control" placeholder="Systolic (120)" required min="60" max="250">
                                    <input type="number" name="diastolic" class="form-control" placeholder="Diastolic (80)" required min="40" max="150">
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Heart Rate (bpm)</label>
                                <input type="number" name="heart_rate" class="form-control" placeholder="72" required min="40" max="200">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Sugar Level (mg/dL)</label>
                                <input type="number" step="0.1" name="sugar_level" class="form-control" placeholder="95.5" required min="40" max="400">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Temperature (°C)</label>
                                <input type="number" step="0.1" name="temperature" class="form-control" placeholder="36.8" required min="34" max="42">
                            </div>

                            <button type="submit" name="submit_vitals" class="btn btn-primary btn-block">Submit & Analyze</button>
                        </form>
                    </div>
                </div>

                <!-- Notifications & Tips -->
                <div>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">🔔 Notifications</h3>
                        </div>
                        <div class="card-body">
                            <?php if (count($notifications) > 0): ?>
                                <?php foreach ($notifications as $notif): ?>
                                    <div class="notification">
                                        <div class="notification-title"><?php echo htmlspecialchars($notif['title']); ?></div>
                                        <div class="notification-message"><?php echo htmlspecialchars($notif['message']); ?></div>
                                        <div class="notification-time"><?php echo format_datetime($notif['created_at']); ?></div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p class="text-muted">No notifications yet</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Vitals -->
            <?php if (count($recent_vitals) > 0): ?>
                <div class="card" style="margin-top: 2rem;">
                    <div class="card-header">
                        <h3 class="card-title">📊 Recent Vitals</h3>
                    </div>
                    <div class="card-body">
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Blood Pressure</th>
                                        <th>Heart Rate</th>
                                        <th>Sugar Level</th>
                                        <th>Temperature</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_vitals as $vital): ?>
                                        <tr>
                                            <td><?php echo format_datetime($vital['recorded_at']); ?></td>
                                            <td><?php echo $vital['blood_pressure_systolic'] . '/' . $vital['blood_pressure_diastolic']; ?> mmHg</td>
                                            <td><?php echo $vital['heart_rate']; ?> bpm</td>
                                            <td><?php echo $vital['sugar_level']; ?> mg/dL</td>
                                            <td><?php echo $vital['temperature']; ?> °C</td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>

                        <?php if ($total_pages > 1): ?>
                            <div class="pagination" style="margin-top: 1.5rem; display: flex; justify-content: center; gap: 0.5rem; align-items: center;">
                                <?php if ($page > 1): ?>
                                    <a href="?page=<?php echo $page - 1; ?>" class="btn btn-secondary btn-sm">&laquo; Prev</a>
                                <?php endif; ?>

                                <?php
                                $start_page = max(1, $page - 2);
                                $end_page = min($total_pages, $page + 2);

                                if ($start_page > 1) {
                                    echo '<a href="?page=1" class="btn btn-secondary btn-sm">1</a>';
                                    if ($start_page > 2) echo '<span class="text-muted">...</span>';
                                }

                                for ($i = $start_page; $i <= $end_page; $i++): ?>
                                    <a href="?page=<?php echo $i; ?>" class="btn <?php echo $i === $page ? 'btn-primary' : 'btn-secondary'; ?> btn-sm">
                                        <?php echo $i; ?>
                                    </a>
                                <?php endfor;

                                if ($end_page < $total_pages) {
                                    if ($end_page < $total_pages - 1) echo '<span class="text-muted">...</span>';
                                    echo '<a href="?page=' . $total_pages . '" class="btn btn-secondary btn-sm">' . $total_pages . '</a>';
                                }
                                ?>

                                <?php if ($page < $total_pages): ?>
                                    <a href="?page=<?php echo $page + 1; ?>" class="btn btn-secondary btn-sm">Next &raquo;</a>
                                <?php endif; ?>
                            </div>
                            <div style="text-align: center; margin-top: 0.5rem;">
                                <small class="text-muted">Showing page <?php echo $page; ?> of <?php echo $total_pages; ?> (<?php echo $total_vitals; ?> total records)</small>
                            </div>
                        <?php endif; ?>

                        <div style="margin-top: 1.5rem; text-align: center;">
                            <a href="history.php" class="btn btn-secondary">View Full History</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>