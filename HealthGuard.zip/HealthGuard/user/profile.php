<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

check_auth();
check_role('user');

$user_id = get_user_id();
$user = get_user_by_id($user_id);

$message = '';
$message_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle profile picture upload
    if (isset($_POST['upload_picture']) && isset($_FILES['profile_picture'])) {
        $result = upload_profile_picture($user_id, $_FILES['profile_picture']);
        $message = '<div class="alert alert-' . ($result['success'] ? 'success' : 'danger') . '">' . $result['message'] . '</div>';
        $user = get_user_by_id($user_id);
    }
    // Handle profile picture deletion
    elseif (isset($_POST['delete_picture'])) {
        $result = delete_profile_picture($user_id);
        $message = '<div class="alert alert-' . ($result['success'] ? 'success' : 'danger') . '">' . $result['message'] . '</div>';
        $user = get_user_by_id($user_id);
    }
    // Handle profile info update
    elseif (isset($_POST['update_profile'])) {
        $name = sanitize_input($_POST['name']);
        $age = !empty($_POST['age']) ? intval($_POST['age']) : null;
        $gender = !empty($_POST['gender']) ? sanitize_input($_POST['gender']) : null;
        $location = !empty($_POST['location']) ? sanitize_input($_POST['location']) : null;

        try {
            $stmt = $pdo->prepare("UPDATE users SET name = ?, age = ?, gender = ?, location = ? WHERE id = ?");
            $stmt->execute([$name, $age, $gender, $location, $user_id]);

            $_SESSION['user_name'] = $name;
            $message = '<div class="alert alert-success">Profile updated successfully!</div>';
            $user = get_user_by_id($user_id);
        } catch (PDOException $e) {
            $message = '<div class="alert alert-danger">Failed to update profile</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - HealthGuard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="dashboard.php" class="navbar-brand">🛡️ HealthGuard</a>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="navbar-nav" id="navbarNav">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="history.php">History</a></li>
                <li><a href="profile.php" class="active">Profile</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Hamburger menu toggle
        const hamburger = document.getElementById('hamburger');
        const navbarNav = document.getElementById('navbarNav');

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarNav.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            }
        });

        // Close menu when clicking on a link
        navbarNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            });
        });
    </script>

    <!-- Profile Content -->
    <div class="dashboard">
        <div class="container" style="max-width: 700px;">
            <div class="dashboard-header">
                <h1 class="dashboard-title">👤 My Profile</h1>
                <p class="dashboard-subtitle">Manage your personal information</p>
            </div>

            <?php echo $message; ?>

            <!-- Profile Picture Section -->
            <div class="card" style="margin-bottom: 2rem;">
                <div class="card-header">
                    <h3 class="card-title">Profile Picture</h3>
                </div>
                <div class="card-body" style="text-align: center;">
                    <div style="margin-bottom: 1.5rem;">
                        <img src="<?php echo get_profile_picture_url($user); ?>" alt="Profile Picture"
                            id="profilePicturePreview"
                            style="width: 150px; height: 150px; border-radius: 50%; object-fit: cover; border: 4px solid var(--primary-solid); box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                    </div>

                    <form method="POST" action="" enctype="multipart/form-data" style="display: inline-block; margin-right: 1rem;">
                        <input type="file" name="profile_picture" id="profilePictureInput" accept="image/jpeg,image/jpg,image/png,image/gif" style="display: none;" onchange="previewImage(this)">
                        <button type="button" class="btn btn-primary" onclick="document.getElementById('profilePictureInput').click()">
                            📷 Choose Picture
                        </button>
                        <button type="submit" name="upload_picture" class="btn btn-primary" id="uploadBtn" style="display: none;">
                            ✓ Upload
                        </button>
                    </form>

                    <?php if (!empty($user['profile_picture'])): ?>
                        <form method="POST" action="" style="display: inline-block;">
                            <button type="submit" name="delete_picture" class="btn" style="background: #ef4444; color: white;" onclick="return confirm('Are you sure you want to remove your profile picture?')">
                                🗑️ Remove Picture
                            </button>
                        </form>
                    <?php endif; ?>

                    <p class="text-muted" style="margin-top: 1rem; font-size: 0.875rem;">
                        Supported formats: JPG, PNG, GIF (Max 2MB)
                    </p>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Personal Information</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="">
                        <div class="form-group">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Age</label>
                                <input type="number" name="age" class="form-control" value="<?php echo $user['age']; ?>" min="1" max="120">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Gender</label>
                                <select name="gender" class="form-control">
                                    <option value="">Select Gender</option>
                                    <option value="male" <?php echo $user['gender'] === 'male' ? 'selected' : ''; ?>>Male</option>
                                    <option value="female" <?php echo $user['gender'] === 'female' ? 'selected' : ''; ?>>Female</option>
                                    <option value="other" <?php echo $user['gender'] === 'other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Location</label>
                            <input type="text" name="location" class="form-control" value="<?php echo htmlspecialchars($user['location']); ?>" placeholder="City, Country">
                        </div>

                        <button type="submit" name="update_profile" class="btn btn-primary btn-block">Update Profile</button>
                    </form>
                </div>
            </div>

            <div class="card" style="margin-top: 2rem;">
                <div class="card-header">
                    <h3 class="card-title">Account Information</h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input type="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" disabled>
                        <small class="text-muted">Email cannot be changed</small>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Account Type</label>
                        <input type="text" class="form-control" value="<?php echo ucfirst($user['role']); ?>" disabled>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Member Since</label>
                        <input type="text" class="form-control" value="<?php echo format_date($user['created_at']); ?>" disabled>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    document.getElementById('profilePicturePreview').src = e.target.result;
                    document.getElementById('uploadBtn').style.display = 'inline-block';
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
</body>

</html>