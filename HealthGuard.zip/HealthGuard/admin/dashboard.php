<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

check_auth();
check_role('admin');

$total_users = get_total_users();

// Get high risk users count - count users with latest high risk assessment
$stmt = $pdo->query("
    SELECT COUNT(DISTINCT user_id) as count 
    FROM risk_assessments ra1
    WHERE risk_level = 'High'
    AND assessed_at = (
        SELECT MAX(assessed_at) 
        FROM risk_assessments ra2 
        WHERE ra2.user_id = ra1.user_id
    )
");
$high_risk_users = $stmt->fetch()['count'];

// Pagination for recent vitals
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get total vitals count for pagination
$stmt = $pdo->query("SELECT COUNT(*) as count FROM vitals");
$total_vitals_count = $stmt->fetch()['count'];
$total_pages = ceil($total_vitals_count / $per_page);

// Get recent vitals submissions with pagination
$stmt = $pdo->prepare("
    SELECT v.*, u.name as user_name, u.email as user_email
    FROM vitals v
    JOIN users u ON v.user_id = u.id
    ORDER BY v.recorded_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute([$per_page, $offset]);
$recent_vitals = $stmt->fetchAll();

// Get total vitals count (this variable is used in the stats overview)
$total_vitals = $total_vitals_count;

// Get risk distribution
$stmt = $pdo->query("
    SELECT risk_level, COUNT(*) as count
    FROM risk_assessments
    WHERE assessed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY risk_level
");
$risk_distribution = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - HealthGuard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="dashboard.php" class="navbar-brand">🛡️ HealthGuard Admin</a>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="navbar-nav" id="navbarNav">
                <li><a href="dashboard.php" class="active">Dashboard</a></li>
                <li><a href="users.php">Users</a></li>
                <li><a href="notifications.php">Notifications</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Hamburger menu toggle
        const hamburger = document.getElementById('hamburger');
        const navbarNav = document.getElementById('navbarNav');

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarNav.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            }
        });

        // Close menu when clicking on a link
        navbarNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            });
        });
    </script>

    <!-- Admin Dashboard -->
    <div class="dashboard">
        <div class="container">
            <div class="dashboard-header">
                <h1 class="dashboard-title">⚡ Admin Dashboard</h1>
                <p class="dashboard-subtitle">System overview and management</p>
            </div>

            <!-- Stats Overview -->
            <div class="grid grid-4" style="margin-bottom: 2rem;">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $total_users; ?></div>
                    <div class="stat-label">Total Users</div>
                </div>

                <div class="stat-card">
                    <div class="stat-value" style="color: var(--danger);"><?php echo $high_risk_users; ?></div>
                    <div class="stat-label">High Risk Users</div>
                </div>

                <div class="stat-card">
                    <div class="stat-value"><?php echo $total_vitals; ?></div>
                    <div class="stat-label">Total Vitals</div>
                </div>

                <div class="stat-card">
                    <div class="stat-value"><?php echo count($recent_vitals); ?></div>
                    <div class="stat-label">Recent Submissions</div>
                </div>
            </div>

            <div class="grid grid-2">
                <!-- Risk Distribution -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">📊 Risk Distribution (Last 30 Days)</h3>
                    </div>
                    <div class="card-body">
                        <div style="display: flex; flex-direction: column; gap: 1rem;">
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                    <div style="width: 20px; height: 20px; background: var(--risk-low); border-radius: 4px;"></div>
                                    <span>Low Risk</span>
                                </div>
                                <span class="stat-value" style="font-size: 1.5rem;"><?php echo $risk_distribution['Low'] ?? 0; ?></span>
                            </div>

                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                    <div style="width: 20px; height: 20px; background: var(--risk-medium); border-radius: 4px;"></div>
                                    <span>Medium Risk</span>
                                </div>
                                <span class="stat-value" style="font-size: 1.5rem;"><?php echo $risk_distribution['Medium'] ?? 0; ?></span>
                            </div>

                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                    <div style="width: 20px; height: 20px; background: var(--risk-high); border-radius: 4px;"></div>
                                    <span>High Risk</span>
                                </div>
                                <span class="stat-value" style="font-size: 1.5rem;"><?php echo $risk_distribution['High'] ?? 0; ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">⚡ Quick Actions</h3>
                    </div>
                    <div class="card-body">
                        <div style="display: flex; flex-direction: column; gap: 1rem;">
                            <a href="users.php" class="btn btn-primary btn-block">👥 Manage Users</a>
                            <a href="notifications.php" class="btn btn-secondary btn-block">🔔 Send Notifications</a>
                            <a href="reports.php" class="btn btn-secondary btn-block">📄 Generate Reports</a>
                            <a href="users.php?filter=high_risk" class="btn btn-danger btn-block">⚠️ View High Risk Users</a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Vitals Submissions -->
            <div class="card" style="margin-top: 2rem;">
                <div class="card-header">
                    <h3 class="card-title">📝 Recent Vitals Submissions</h3>
                </div>
                <div class="card-body">
                    <?php if (count($recent_vitals) > 0): ?>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>User</th>
                                        <th>Date & Time</th>
                                        <th>Blood Pressure</th>
                                        <th>Heart Rate</th>
                                        <th>Sugar Level</th>
                                        <th>Temperature</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_vitals as $vital): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($vital['user_name']); ?></td>
                                            <td><?php echo format_datetime($vital['recorded_at']); ?></td>
                                            <td><?php echo $vital['blood_pressure_systolic'] . '/' . $vital['blood_pressure_diastolic']; ?> mmHg</td>
                                            <td><?php echo $vital['heart_rate']; ?> bpm</td>
                                            <td><?php echo $vital['sugar_level']; ?> mg/dL</td>
                                            <td><?php echo $vital['temperature']; ?> °C</td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>

                            <!-- Pagination -->
                            <?php if ($total_pages > 1): ?>
                                <div style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--border-color);">
                                    <?php if ($page > 1): ?>
                                        <a href="dashboard.php?page=<?php echo $page - 1; ?>" class="btn btn-sm btn-secondary">← Previous</a>
                                    <?php endif; ?>

                                    <div style="display: flex; gap: 0.25rem;">
                                        <?php
                                        $start_page = max(1, $page - 2);
                                        $end_page = min($total_pages, $page + 2);

                                        if ($start_page > 1): ?>
                                            <a href="dashboard.php?page=1" class="btn btn-sm <?php echo $page === 1 ? 'btn-primary' : 'btn-secondary'; ?>">1</a>
                                            <?php if ($start_page > 2): ?>
                                                <span style="padding: 0.5rem;">...</span>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                                            <a href="dashboard.php?page=<?php echo $i; ?>" class="btn btn-sm <?php echo $page === $i ? 'btn-primary' : 'btn-secondary'; ?>"><?php echo $i; ?></a>
                                        <?php endfor; ?>

                                        <?php if ($end_page < $total_pages): ?>
                                            <?php if ($end_page < $total_pages - 1): ?>
                                                <span style="padding: 0.5rem;">...</span>
                                            <?php endif; ?>
                                            <a href="dashboard.php?page=<?php echo $total_pages; ?>" class="btn btn-sm <?php echo $page === $total_pages ? 'btn-primary' : 'btn-secondary'; ?>"><?php echo $total_pages; ?></a>
                                        <?php endif; ?>
                                    </div>

                                    <?php if ($page < $total_pages): ?>
                                        <a href="dashboard.php?page=<?php echo $page + 1; ?>" class="btn btn-sm btn-secondary">Next →</a>
                                    <?php endif; ?>
                                </div>

                                <div style="text-align: center; margin-top: 1rem;">
                                    <small class="text-muted">
                                        Showing <?php echo $offset + 1; ?>-<?php echo min($offset + $per_page, $total_vitals_count); ?> of <?php echo $total_vitals_count; ?> vitals
                                    </small>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted text-center">No vitals submitted yet</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>

</html>