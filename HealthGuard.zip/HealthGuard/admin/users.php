<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

check_auth();
check_role('admin');

$message = '';

// Handle delete user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user'])) {
    $user_id = intval($_POST['user_id']);
    $result = delete_user($user_id);
    $message = '<div class="alert alert-' . ($result['success'] ? 'success' : 'danger') . '">' . $result['message'] . '</div>';
}

// Handle edit user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_user'])) {
    $user_id = intval($_POST['user_id']);
    $name = sanitize_input($_POST['name']);
    $email = sanitize_input($_POST['email']);
    $age = !empty($_POST['age']) ? intval($_POST['age']) : null;
    $gender = !empty($_POST['gender']) ? sanitize_input($_POST['gender']) : null;
    $location = !empty($_POST['location']) ? sanitize_input($_POST['location']) : null;

    $result = update_user($user_id, $name, $email, $age, $gender, $location);
    $message = '<div class="alert alert-' . ($result['success'] ? 'success' : 'danger') . '">' . $result['message'] . '</div>';
}

// Get all users with their latest risk assessment
$filter = $_GET['filter'] ?? 'all';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$location_filter = $_GET['location'] ?? '';

// Pagination
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

$sql = "
    SELECT u.*, 
           (SELECT risk_level FROM risk_assessments WHERE user_id = u.id ORDER BY assessed_at DESC LIMIT 1) as latest_risk,
           (SELECT COUNT(*) FROM vitals WHERE user_id = u.id) as vitals_count
    FROM users u 
    WHERE u.role = 'user'
";

$params = [];

// Add date filter
if (!empty($date_from) && !empty($date_to)) {
    $sql .= " AND u.created_at BETWEEN ? AND ?";
    $params[] = $date_from . ' 00:00:00';
    $params[] = $date_to . ' 23:59:59';
}

// Add location filter
if (!empty($location_filter)) {
    $sql .= " AND u.location LIKE ?";
    $params[] = '%' . $location_filter . '%';
}

if ($filter === 'high_risk') {
    $sql .= " HAVING latest_risk = 'High'";
}

// Get total count before adding LIMIT
$count_sql = "SELECT COUNT(*) as total FROM (" . $sql . ") as filtered_users";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_users_count = $count_stmt->fetch()['total'];
$total_pages = ceil($total_users_count / $per_page);

$sql .= " ORDER BY u.created_at DESC LIMIT ? OFFSET ?";
$params[] = $per_page;
$params[] = $offset;

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

// Get unique locations for filter dropdown
$locations_query = $pdo->query("SELECT DISTINCT location FROM users WHERE location IS NOT NULL AND location != '' ORDER BY location");
$locations = $locations_query->fetchAll(PDO::FETCH_COLUMN);

// Get user details if viewing specific user
$selected_user = null;
$user_vitals = [];
if (isset($_GET['user_id'])) {
    $selected_user = get_user_by_id($_GET['user_id']);
    $user_vitals = get_user_vitals($_GET['user_id'], 10);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - HealthGuard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="dashboard.php" class="navbar-brand">🛡️ HealthGuard Admin</a>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="navbar-nav" id="navbarNav">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="users.php" class="active">Users</a></li>
                <li><a href="notifications.php">Notifications</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Hamburger menu toggle
        const hamburger = document.getElementById('hamburger');
        const navbarNav = document.getElementById('navbarNav');

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarNav.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            }
        });

        // Close menu when clicking on a link
        navbarNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            });
        });
    </script>

    <!-- Users Management -->
    <div class="dashboard">
        <div class="container">
            <div class="dashboard-header">
                <h1 class="dashboard-title">👥 User Management</h1>
                <p class="dashboard-subtitle">View and manage all users</p>
            </div>

            <?php echo $message; ?>

            <!-- Filter Options -->
            <div class="card" style="margin-bottom: 2rem;">
                <div class="card-header">
                    <h3 class="card-title">🔍 Filter Users</h3>
                </div>
                <div class="card-body">
                    <form method="GET" action="users.php">
                        <div class="grid grid-2" style="margin-bottom: 1rem;">
                            <!-- Risk Level Filter -->
                            <div class="form-group">
                                <label class="form-label">Risk Level</label>
                                <select name="filter" class="form-control">
                                    <option value="all" <?php echo $filter === 'all' ? 'selected' : ''; ?>>All Users</option>
                                    <option value="high_risk" <?php echo $filter === 'high_risk' ? 'selected' : ''; ?>>High Risk Only</option>
                                </select>
                            </div>

                            <!-- Location Filter -->
                            <div class="form-group">
                                <label class="form-label">Location</label>
                                <select name="location" class="form-control">
                                    <option value="">All Locations</option>
                                    <?php foreach ($locations as $loc): ?>
                                        <option value="<?php echo htmlspecialchars($loc); ?>" <?php echo $location_filter === $loc ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($loc); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="grid grid-2" style="margin-bottom: 1rem;">
                            <!-- Date From -->
                            <div class="form-group">
                                <label class="form-label">Member Since (From)</label>
                                <input type="date" name="date_from" class="form-control" value="<?php echo htmlspecialchars($date_from); ?>">
                            </div>

                            <!-- Date To -->
                            <div class="form-group">
                                <label class="form-label">Member Since (To)</label>
                                <input type="date" name="date_to" class="form-control" value="<?php echo htmlspecialchars($date_to); ?>">
                            </div>
                        </div>

                        <div style="display: flex; gap: 1rem;">
                            <button type="submit" class="btn btn-primary">Apply Filters</button>
                            <a href="users.php" class="btn btn-secondary">Clear Filters</a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Users Table -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Users List (<?php echo count($users); ?> total)</h3>
                </div>
                <div class="card-body">
                    <?php if (count($users) > 0): ?>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Age</th>
                                        <th>Location</th>
                                        <th>Vitals Count</th>
                                        <th>Latest Risk</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $user): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($user['name']); ?></td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td><?php echo $user['age'] ?? 'N/A'; ?></td>
                                            <td><?php echo htmlspecialchars($user['location']) ?? 'N/A'; ?></td>
                                            <td><?php echo $user['vitals_count']; ?></td>
                                            <td>
                                                <?php if ($user['latest_risk']): ?>
                                                    <span class="risk-badge risk-<?php echo strtolower($user['latest_risk']); ?>">
                                                        <?php echo $user['latest_risk']; ?>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="text-muted">No data</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="users.php?user_id=<?php echo $user['id']; ?>" class="btn btn-sm btn-secondary">View</a>
                                                <a href="users.php?user_id=<?php echo $user['id']; ?>&edit=1" class="btn btn-sm btn-primary">Edit</a>
                                                <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">
                                                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                    <button type="submit" name="delete_user" class="btn btn-sm btn-danger">Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>

                            <!-- Pagination -->
                            <?php if ($total_pages > 1): ?>
                                <?php
                                // Build query string for pagination links to preserve filters
                                $query_params = [];
                                if ($filter !== 'all') $query_params['filter'] = $filter;
                                if (!empty($date_from)) $query_params['date_from'] = $date_from;
                                if (!empty($date_to)) $query_params['date_to'] = $date_to;
                                if (!empty($location_filter)) $query_params['location'] = $location_filter;

                                function build_page_url($page_num, $params)
                                {
                                    $params['page'] = $page_num;
                                    return 'users.php?' . http_build_query($params);
                                }
                                ?>

                                <div style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--border-color);">
                                    <?php if ($page > 1): ?>
                                        <a href="<?php echo build_page_url($page - 1, $query_params); ?>" class="btn btn-sm btn-secondary">← Previous</a>
                                    <?php endif; ?>

                                    <div style="display: flex; gap: 0.25rem;">
                                        <?php
                                        $start_page = max(1, $page - 2);
                                        $end_page = min($total_pages, $page + 2);

                                        if ($start_page > 1): ?>
                                            <a href="<?php echo build_page_url(1, $query_params); ?>" class="btn btn-sm <?php echo $page === 1 ? 'btn-primary' : 'btn-secondary'; ?>">1</a>
                                            <?php if ($start_page > 2): ?>
                                                <span style="padding: 0.5rem;">...</span>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                                            <a href="<?php echo build_page_url($i, $query_params); ?>" class="btn btn-sm <?php echo $page === $i ? 'btn-primary' : 'btn-secondary'; ?>"><?php echo $i; ?></a>
                                        <?php endfor; ?>

                                        <?php if ($end_page < $total_pages): ?>
                                            <?php if ($end_page < $total_pages - 1): ?>
                                                <span style="padding: 0.5rem;">...</span>
                                            <?php endif; ?>
                                            <a href="<?php echo build_page_url($total_pages, $query_params); ?>" class="btn btn-sm <?php echo $page === $total_pages ? 'btn-primary' : 'btn-secondary'; ?>"><?php echo $total_pages; ?></a>
                                        <?php endif; ?>
                                    </div>

                                    <?php if ($page < $total_pages): ?>
                                        <a href="<?php echo build_page_url($page + 1, $query_params); ?>" class="btn btn-sm btn-secondary">Next →</a>
                                    <?php endif; ?>
                                </div>

                                <div style="text-align: center; margin-top: 1rem;">
                                    <small class="text-muted">
                                        Showing <?php echo $offset + 1; ?>-<?php echo min($offset + $per_page, $total_users_count); ?> of <?php echo $total_users_count; ?> users
                                    </small>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <p class="text-muted text-center">No users found</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- User Details Modal -->
            <?php if ($selected_user): ?>
                <?php $edit_mode = isset($_GET['edit']); ?>
                <div class="card" style="margin-top: 2rem; border: 2px solid var(--primary-solid);">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <h3 class="card-title"><?php echo $edit_mode ? 'Edit' : 'View'; ?> User: <?php echo htmlspecialchars($selected_user['name']); ?></h3>
                            <a href="users.php" class="btn btn-sm btn-secondary">Close</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <?php if ($edit_mode): ?>
                            <!-- Edit Form -->
                            <form method="POST" action="">
                                <input type="hidden" name="user_id" value="<?php echo $selected_user['id']; ?>">

                                <div class="form-group">
                                    <label class="form-label">Full Name</label>
                                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($selected_user['name']); ?>" required>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Email Address</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($selected_user['email']); ?>" required>
                                </div>

                                <div class="form-row">
                                    <div class="form-group">
                                        <label class="form-label">Age</label>
                                        <input type="number" name="age" class="form-control" value="<?php echo $selected_user['age']; ?>" min="1" max="120">
                                    </div>

                                    <div class="form-group">
                                        <label class="form-label">Gender</label>
                                        <select name="gender" class="form-control">
                                            <option value="">Select Gender</option>
                                            <option value="male" <?php echo $selected_user['gender'] === 'male' ? 'selected' : ''; ?>>Male</option>
                                            <option value="female" <?php echo $selected_user['gender'] === 'female' ? 'selected' : ''; ?>>Female</option>
                                            <option value="other" <?php echo $selected_user['gender'] === 'other' ? 'selected' : ''; ?>>Other</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="form-label">Location</label>
                                    <input type="text" name="location" class="form-control" value="<?php echo htmlspecialchars($selected_user['location']); ?>" placeholder="City, Country">
                                </div>

                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" name="edit_user" class="btn btn-primary">Save Changes</button>
                                    <a href="users.php?user_id=<?php echo $selected_user['id']; ?>" class="btn btn-secondary">Cancel</a>
                                </div>
                            </form>
                        <?php else: ?>
                            <!-- View Mode -->
                            <div class="grid grid-2">
                                <div>
                                    <h4>Personal Information</h4>
                                    <p><strong>Email:</strong> <?php echo htmlspecialchars($selected_user['email']); ?></p>
                                    <p><strong>Age:</strong> <?php echo $selected_user['age'] ?? 'N/A'; ?></p>
                                    <p><strong>Gender:</strong> <?php echo ucfirst($selected_user['gender']) ?? 'N/A'; ?></p>
                                    <p><strong>Location:</strong> <?php echo htmlspecialchars($selected_user['location']) ?? 'N/A'; ?></p>
                                    <p><strong>Member Since:</strong> <?php echo format_date($selected_user['created_at']); ?></p>
                                </div>

                                <div>
                                    <h4>Recent Vitals</h4>
                                    <?php if (count($user_vitals) > 0): ?>
                                        <?php foreach (array_slice($user_vitals, 0, 5) as $vital): ?>
                                            <div style="margin-bottom: 0.5rem; padding: 0.5rem; background: var(--bg-secondary); border-radius: var(--radius-sm);">
                                                <small class="text-muted"><?php echo format_datetime($vital['recorded_at']); ?></small><br>
                                                <small>BP: <?php echo $vital['blood_pressure_systolic'] . '/' . $vital['blood_pressure_diastolic']; ?> | HR: <?php echo $vital['heart_rate']; ?> | Sugar: <?php echo $vital['sugar_level']; ?></small>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p class="text-muted">No vitals recorded</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>

</html>