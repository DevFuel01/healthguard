<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

check_auth();
check_role('admin');

// Get comprehensive statistics
$stats = [];

// Total users
$stats['total_users'] = get_total_users();

// Total vitals
$stmt = $pdo->query("SELECT COUNT(*) as count FROM vitals");
$stats['total_vitals'] = $stmt->fetch()['count'];

// Risk distribution
$stmt = $pdo->query("
    SELECT risk_level, COUNT(*) as count 
    FROM risk_assessments 
    GROUP BY risk_level
");
$risk_dist = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
$stats['low_risk'] = $risk_dist['Low'] ?? 0;
$stats['medium_risk'] = $risk_dist['Medium'] ?? 0;
$stats['high_risk'] = $risk_dist['High'] ?? 0;

// Average vitals
$stmt = $pdo->query("
    SELECT 
        AVG(blood_pressure_systolic) as avg_systolic,
        AVG(blood_pressure_diastolic) as avg_diastolic,
        AVG(heart_rate) as avg_hr,
        AVG(sugar_level) as avg_sugar,
        AVG(temperature) as avg_temp
    FROM vitals
");
$avg_vitals = $stmt->fetch();

// Handle CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="healthguard_report_' . date('Y-m-d') . '.csv"');

    $output = fopen('php://output', 'w');

    // System Statistics
    fputcsv($output, ['HealthGuard System Report - Generated: ' . date('Y-m-d H:i:s')]);
    fputcsv($output, []);
    fputcsv($output, ['SYSTEM STATISTICS']);
    fputcsv($output, ['Metric', 'Value']);
    fputcsv($output, ['Total Users', $stats['total_users']]);
    fputcsv($output, ['Total Vitals Recorded', $stats['total_vitals']]);
    fputcsv($output, ['Low Risk Assessments', $stats['low_risk']]);
    fputcsv($output, ['Medium Risk Assessments', $stats['medium_risk']]);
    fputcsv($output, ['High Risk Assessments', $stats['high_risk']]);
    fputcsv($output, []);

    // Average Vitals
    fputcsv($output, ['AVERAGE VITALS']);
    fputcsv($output, ['Metric', 'Value']);
    fputcsv($output, ['Blood Pressure Systolic', round($avg_vitals['avg_systolic'], 1) . ' mmHg']);
    fputcsv($output, ['Blood Pressure Diastolic', round($avg_vitals['avg_diastolic'], 1) . ' mmHg']);
    fputcsv($output, ['Heart Rate', round($avg_vitals['avg_hr'], 1) . ' bpm']);
    fputcsv($output, ['Sugar Level', round($avg_vitals['avg_sugar'], 1) . ' mg/dL']);
    fputcsv($output, ['Temperature', round($avg_vitals['avg_temp'], 1) . ' °C']);
    fputcsv($output, []);

    // User Details
    fputcsv($output, ['USER DETAILS']);
    fputcsv($output, ['Name', 'Email', 'Age', 'Location', 'Vitals Count', 'Latest Risk']);

    $users_query = $pdo->query("
        SELECT u.*, 
               (SELECT risk_level FROM risk_assessments WHERE user_id = u.id ORDER BY assessed_at DESC LIMIT 1) as latest_risk,
               (SELECT COUNT(*) FROM vitals WHERE user_id = u.id) as vitals_count
        FROM users u 
        WHERE u.role = 'user'
        ORDER BY u.name
    ");

    while ($user = $users_query->fetch()) {
        fputcsv($output, [
            $user['name'],
            $user['email'],
            $user['age'] ?? 'N/A',
            $user['location'] ?? 'N/A',
            $user['vitals_count'],
            $user['latest_risk'] ?? 'No data'
        ]);
    }

    fclose($output);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - HealthGuard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="dashboard.php" class="navbar-brand">🛡️ HealthGuard Admin</a>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="navbar-nav" id="navbarNav">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="users.php">Users</a></li>
                <li><a href="notifications.php">Notifications</a></li>
                <li><a href="reports.php" class="active">Reports</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Hamburger menu toggle
        const hamburger = document.getElementById('hamburger');
        const navbarNav = document.getElementById('navbarNav');

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarNav.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            }
        });

        // Close menu when clicking on a link
        navbarNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            });
        });
    </script>

    <!-- Reports -->
    <div class="dashboard">
        <div class="container">
            <div class="dashboard-header">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h1 class="dashboard-title">📄 System Reports</h1>
                        <p class="dashboard-subtitle">Comprehensive health monitoring statistics</p>
                    </div>
                    <a href="reports.php?export=csv" class="btn btn-success">📥 Export CSV</a>
                </div>
            </div>

            <!-- System Statistics -->
            <div class="grid grid-4" style="margin-bottom: 2rem;">
                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['total_users']; ?></div>
                    <div class="stat-label">Total Users</div>
                </div>

                <div class="stat-card">
                    <div class="stat-value"><?php echo $stats['total_vitals']; ?></div>
                    <div class="stat-label">Total Vitals</div>
                </div>

                <div class="stat-card">
                    <div class="stat-value" style="color: var(--success);"><?php echo $stats['low_risk']; ?></div>
                    <div class="stat-label">Low Risk</div>
                </div>

                <div class="stat-card">
                    <div class="stat-value" style="color: var(--danger);"><?php echo $stats['high_risk']; ?></div>
                    <div class="stat-label">High Risk</div>
                </div>
            </div>

            <div class="grid grid-2">
                <!-- Risk Distribution Chart -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Risk Level Distribution</h3>
                    </div>
                    <div class="card-body">
                        <canvas id="riskChart"></canvas>
                    </div>
                </div>

                <!-- Average Vitals -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Average Vitals</h3>
                    </div>
                    <div class="card-body">
                        <div style="display: flex; flex-direction: column; gap: 1rem;">
                            <div>
                                <div class="text-muted" style="font-size: 0.875rem;">Blood Pressure</div>
                                <div class="stat-value" style="font-size: 1.5rem;">
                                    <?php echo round($avg_vitals['avg_systolic'], 1); ?>/<?php echo round($avg_vitals['avg_diastolic'], 1); ?>
                                </div>
                                <div class="text-muted" style="font-size: 0.75rem;">mmHg</div>
                            </div>

                            <div>
                                <div class="text-muted" style="font-size: 0.875rem;">Heart Rate</div>
                                <div class="stat-value" style="font-size: 1.5rem;"><?php echo round($avg_vitals['avg_hr'], 1); ?></div>
                                <div class="text-muted" style="font-size: 0.75rem;">bpm</div>
                            </div>

                            <div>
                                <div class="text-muted" style="font-size: 0.875rem;">Sugar Level</div>
                                <div class="stat-value" style="font-size: 1.5rem;"><?php echo round($avg_vitals['avg_sugar'], 1); ?></div>
                                <div class="text-muted" style="font-size: 0.75rem;">mg/dL</div>
                            </div>

                            <div>
                                <div class="text-muted" style="font-size: 0.875rem;">Temperature</div>
                                <div class="stat-value" style="font-size: 1.5rem;"><?php echo round($avg_vitals['avg_temp'], 1); ?></div>
                                <div class="text-muted" style="font-size: 0.75rem;">°C</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Export Information -->
            <div class="card" style="margin-top: 2rem;">
                <div class="card-header">
                    <h3 class="card-title">📊 Report Export</h3>
                </div>
                <div class="card-body">
                    <p>Click the "Export CSV" button above to download a comprehensive report including:</p>
                    <ul style="color: var(--text-secondary); margin-left: 1.5rem;">
                        <li>System statistics (total users, vitals, risk distribution)</li>
                        <li>Average vitals across all users</li>
                        <li>Detailed user information with risk levels</li>
                        <li>Complete vitals history</li>
                    </ul>
                    <p class="text-muted" style="margin-top: 1rem;">The CSV file can be opened in Excel, Google Sheets, or any spreadsheet application for further analysis.</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Risk Distribution Pie Chart
        new Chart(document.getElementById('riskChart'), {
            type: 'doughnut',
            data: {
                labels: ['Low Risk', 'Medium Risk', 'High Risk'],
                datasets: [{
                    data: [<?php echo $stats['low_risk']; ?>, <?php echo $stats['medium_risk']; ?>, <?php echo $stats['high_risk']; ?>],
                    backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#cbd5e1',
                            padding: 15
                        }
                    }
                }
            }
        });
    </script>
</body>

</html>