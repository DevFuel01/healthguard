<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';

check_auth();
check_role('admin');

$message = '';

// Handle notification sending
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize_input($_POST['title']);
    $notification_message = sanitize_input($_POST['message']);
    $type = sanitize_input($_POST['type']);
    $send_to = $_POST['send_to'];

    if (empty($title) || empty($notification_message)) {
        $message = '<div class="alert alert-danger">Please fill in all fields</div>';
    } else {
        try {
            if ($send_to === 'all') {
                // Send to all users (NULL user_id means broadcast)
                $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (NULL, ?, ?, ?)");
                $stmt->execute([$title, $notification_message, $type]);
            } else {
                // Send to specific user
                $stmt = $pdo->prepare("INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)");
                $stmt->execute([$send_to, $title, $notification_message, $type]);
            }

            $message = '<div class="alert alert-success">Notification sent successfully!</div>';
        } catch (PDOException $e) {
            $message = '<div class="alert alert-danger">Failed to send notification</div>';
        }
    }
}

// Pagination for recent notifications
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get total notifications count for pagination
$stmt = $pdo->query("SELECT COUNT(*) as count FROM notifications");
$total_notifications_count = $stmt->fetch()['count'];
$total_pages = ceil($total_notifications_count / $per_page);

// Get recent notifications with pagination
$stmt = $pdo->prepare("
    SELECT n.*, u.name as recipient_name 
    FROM notifications n 
    LEFT JOIN users u ON n.user_id = u.id 
    ORDER BY n.created_at DESC 
    LIMIT ? OFFSET ?
");
$stmt->execute([$per_page, $offset]);
$recent_notifications = $stmt->fetchAll();

// Get all users for the dropdown
$all_users = get_all_users();

// Get all users for the recipient dropdown
$stmt = $pdo->query("SELECT id, name, email FROM users WHERE role = 'user' ORDER BY name");
$users = $stmt->fetchAll();

// Health tips templates
$health_tips = [
    ['title' => 'Daily Exercise', 'message' => 'Regular physical activity for at least 30 minutes daily can reduce disease risk by 50%.'],
    ['title' => 'Balanced Nutrition', 'message' => 'A balanced diet rich in fruits and vegetables strengthens your immune system.'],
    ['title' => 'Quality Sleep', 'message' => 'Quality sleep of 7-8 hours is essential for disease prevention and recovery.'],
    ['title' => 'Stress Management', 'message' => 'Managing stress through meditation or yoga can significantly improve heart health.'],
    ['title' => 'Stay Hydrated', 'message' => 'Proper hydration helps regulate body temperature and supports vital organ function.'],
    ['title' => 'Regular Check-ups', 'message' => 'Schedule regular health check-ups to catch potential issues early.'],
];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - HealthGuard</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <a href="dashboard.php" class="navbar-brand">🛡️ HealthGuard Admin</a>
            <button class="hamburger" id="hamburger" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="navbar-nav" id="navbarNav">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="users.php">Users</a></li>
                <li><a href="notifications.php" class="active">Notifications</a></li>
                <li><a href="reports.php">Reports</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <script>
        // Hamburger menu toggle
        const hamburger = document.getElementById('hamburger');
        const navbarNav = document.getElementById('navbarNav');

        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navbarNav.classList.toggle('active');
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!hamburger.contains(e.target) && !navbarNav.contains(e.target)) {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            }
        });

        // Close menu when clicking on a link
        navbarNav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navbarNav.classList.remove('active');
            });
        });
    </script>

    <!-- Notifications Management -->
    <div class="dashboard">
        <div class="container">
            <div class="dashboard-header">
                <h1 class="dashboard-title">🔔 Notifications Management</h1>
                <p class="dashboard-subtitle">Send notifications and health tips to users</p>
            </div>

            <?php echo $message; ?>

            <div class="grid grid-2">
                <!-- Send Notification Form -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Send Notification</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="">
                            <div class="form-group">
                                <label class="form-label">Send To</label>
                                <select name="send_to" class="form-control" required>
                                    <option value="all">All Users (Broadcast)</option>
                                    <optgroup label="Specific Users">
                                        <?php foreach ($all_users as $user): ?>
                                            <option value="<?php echo $user['id']; ?>"><?php echo htmlspecialchars($user['name']) . ' (' . htmlspecialchars($user['email']) . ')'; ?></option>
                                        <?php endforeach; ?>
                                    </optgroup>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Notification Type</label>
                                <select name="type" class="form-control" required>
                                    <option value="info">Info</option>
                                    <option value="tip">Health Tip</option>
                                    <option value="warning">Warning</option>
                                    <option value="alert">Alert</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Title</label>
                                <input type="text" name="title" class="form-control" placeholder="Notification title" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Message</label>
                                <textarea name="message" class="form-control" rows="4" placeholder="Notification message" required style="resize: vertical;"></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block">Send Notification</button>
                        </form>
                    </div>
                </div>

                <!-- Health Tips Templates -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">💡 Health Tips Templates</h3>
                    </div>
                    <div class="card-body">
                        <p class="text-muted" style="margin-bottom: 1rem;">Click to use a template</p>
                        <?php foreach ($health_tips as $tip): ?>
                            <div class="notification" style="cursor: pointer;" onclick="fillForm('<?php echo htmlspecialchars($tip['title']); ?>', '<?php echo htmlspecialchars($tip['message']); ?>')">
                                <div class="notification-title"><?php echo htmlspecialchars($tip['title']); ?></div>
                                <div class="notification-message"><?php echo htmlspecialchars($tip['message']); ?></div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Recent Notifications -->
            <div class="card" style="margin-top: 2rem;">
                <div class="card-header">
                    <h3 class="card-title">Recent Notifications</h3>
                </div>
                <div class="card-body">
                    <?php if (count($recent_notifications) > 0): ?>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Recipient</th>
                                        <th>Type</th>
                                        <th>Title</th>
                                        <th>Message</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_notifications as $notif): ?>
                                        <tr>
                                            <td><?php echo format_datetime($notif['created_at']); ?></td>
                                            <td><?php echo $notif['recipient_name'] ? htmlspecialchars($notif['recipient_name']) : '<strong>All Users</strong>'; ?></td>
                                            <td><span class="risk-badge" style="background: var(--info);"><?php echo ucfirst($notif['type']); ?></span></td>
                                            <td><?php echo htmlspecialchars($notif['title']); ?></td>
                                            <td><?php echo htmlspecialchars(substr($notif['message'], 0, 50)) . (strlen($notif['message']) > 50 ? '...' : ''); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>

                            <!-- Pagination -->
                            <?php if ($total_pages > 1): ?>
                                <div style="display: flex; justify-content: center; align-items: center; gap: 0.5rem; margin-top: 1.5rem; padding-top: 1rem; border-top: 1px solid var(--border-color);">
                                    <?php if ($page > 1): ?>
                                        <a href="notifications.php?page=<?php echo $page - 1; ?>" class="btn btn-sm btn-secondary">← Previous</a>
                                    <?php endif; ?>

                                    <div style="display: flex; gap: 0.25rem;">
                                        <?php
                                        $start_page = max(1, $page - 2);
                                        $end_page = min($total_pages, $page + 2);

                                        if ($start_page > 1): ?>
                                            <a href="notifications.php?page=1" class="btn btn-sm <?php echo $page === 1 ? 'btn-primary' : 'btn-secondary'; ?>">1</a>
                                            <?php if ($start_page > 2): ?>
                                                <span style="padding: 0.5rem;">...</span>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        <?php for ($i = $start_page; $i <= $end_page; $i++): ?>
                                            <a href="notifications.php?page=<?php echo $i; ?>" class="btn btn-sm <?php echo $page === $i ? 'btn-primary' : 'btn-secondary'; ?>"><?php echo $i; ?></a>
                                        <?php endfor; ?>

                                        <?php if ($end_page < $total_pages): ?>
                                            <?php if ($end_page < $total_pages - 1): ?>
                                                <span style="padding: 0.5rem;">...</span>
                                            <?php endif; ?>
                                            <a href="notifications.php?page=<?php echo $total_pages; ?>" class="btn btn-sm <?php echo $page === $total_pages ? 'btn-primary' : 'btn-secondary'; ?>"><?php echo $total_pages; ?></a>
                                        <?php endif; ?>
                                    </div>

                                    <?php if ($page < $total_pages): ?>
                                        <a href="notifications.php?page=<?php echo $page + 1; ?>" class="btn btn-sm btn-secondary">Next →</a>
                                    <?php endif; ?>
                                </div>

                                <div style="text-align: center; margin-top: 1rem;">
                                    <small class="text-muted">
                                        Showing <?php echo $offset + 1; ?>-<?php echo min($offset + $per_page, $total_notifications_count); ?> of <?php echo $total_notifications_count; ?> notifications
                                    </small>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <p class="text-muted text-center">No notifications sent yet</p>
                        <?php endif; ?>
                        </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function fillForm(title, message) {
            document.querySelector('input[name="title"]').value = title;
            document.querySelector('textarea[name="message"]').value = message;
            document.querySelector('select[name="type"]').value = 'tip';
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
    </script>
</body>

</html>